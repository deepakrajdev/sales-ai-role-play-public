/**
 * ================================================
 * VOICE CALL - Professional 3-Column Layout
 * Left: Session Info | Center: Avatar with Tooltip | Right: Transcript
 * ================================================
 */

let voiceCallState = {
    isCallActive: false,
    isSpeaking: false,
    isListening: false,
    sessionId: null,
    callStartTime: null,
    callTimer: null,
    conversationTranscript: [],
    recognition: null,
};

// Initialize Web Speech API
if ('webkitSpeechRecognition' in window) {
    console.log('[Voice Call] ✅ webkitSpeechRecognition available');
    const SpeechRecognition = window.webkitSpeechRecognition;
    voiceCallState.recognition = new SpeechRecognition();
} else if ('SpeechRecognition' in window) {
    console.log('[Voice Call] ✅ SpeechRecognition available');
    const SpeechRecognition = window.SpeechRecognition;
    voiceCallState.recognition = new SpeechRecognition();
} else {
    console.error('[Voice Call] ❌ Speech Recognition not supported in this browser');
}

// Configure recognition if available
if (voiceCallState.recognition) {
    voiceCallState.recognition.continuous = false;      // Stop after one utterance
    voiceCallState.recognition.interimResults = true;   // Get interim results
    voiceCallState.recognition.language = 'en-US';      // English US
    console.log('[Voice Call] ✅ Recognition configured - continuous:', voiceCallState.recognition.continuous, 'interimResults:', voiceCallState.recognition.interimResults);
} else {
    console.error('[Voice Call] ❌ Cannot configure recognition - not available');
}

/**
 * Start voice call
 */
async function startVoiceCall() {
    console.log('[Voice Call] ========== STARTING VOICE CALL ==========');
    console.log('[Voice Call] Session data:', window.sessionData);
    
    try {
        // Validate session data
        if (!window.sessionData || !window.sessionData.personaId || !window.sessionData.policyFilename) {
            alert('Please complete the setup: Select persona and policy');
            console.error('[Voice Call] ❌ Missing session data:', window.sessionData);
            return;
        }

        // Get session data from window
        const policyName = window.sessionData.policyFilename;
        const personaName = window.sessionData.personaName || 'Customer';
        const personaIcon = window.sessionData.personaIcon || '';
        const personaId = window.sessionData.personaId;
        const traits = window.sessionData.traits || {};

        console.log('[Voice Call] ✅ Session data validated:', { policyName, personaId, personaName, traits });

        // Initialize session via API
        const sessionConfig = {
            mode: 'practice_pitch',
            policy: policyName.endsWith('.pdf') ? policyName : policyName + '.pdf',
            persona: personaId,
            traits: traits
        };

        console.log('[Voice Call] 📤 Sending session start request:', sessionConfig);

        const response = await fetch('http://localhost:8000/api/sessions/start', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(sessionConfig)
        });

        console.log('[Voice Call] Response status:', response.status);

        if (!response.ok) {
            const errorData = await response.json();
            console.error('[Voice Call] ❌ API Error:', response.status, errorData);
            throw new Error(`Failed to start session: ${response.status} - ${errorData.detail || errorData.error}`);
        }
        
        const data = await response.json();
        console.log('[Voice Call] ✅ Session created:', data);
        
        // Store session ID in BOTH places
        voiceCallState.sessionId = data.session_id;
        window.sessionData.sessionId = data.session_id;  // IMPORTANT: api.js expects it here
        
        voiceCallState.isCallActive = true;
        voiceCallState.callStartTime = Date.now();

        console.log('[Voice Call] ✅ Session ID stored in:', { voiceCallState: voiceCallState.sessionId, windowSessionData: window.sessionData.sessionId });

        // Initialize voice call page UI
        initializeVoiceCallPage(personaName, personaIcon, policyName);

        // Navigate to voice call page
        goToScreen('voice-call');

        // Start call timer
        startCallTimer();

        // Agent talks first - no AI greeting, user should speak first
        updateCallStatus('Ready - Speak when ready');

        console.log('[Voice Call] ========== CALL READY FOR VOICE INPUT ==========');
    } catch (error) {
        console.error('[Voice Call] ❌ Error starting call:', error);
        updateCallStatus('Connection Failed: ' + error.message);
        alert('Failed to start call: ' + error.message);
    }
}

/**
 * Initialize voice call page with session data
 */
function initializeVoiceCallPage(personaName, personaIcon, policyName) {
    // Update session info panel
    document.getElementById('call-customer-name').textContent = personaName;
    document.getElementById('call-policy-name').textContent = policyName;
    document.getElementById('call-status-text').textContent = 'Connected';
    document.getElementById('call-duration').textContent = '0:00';

    // Update avatar
    const avatarIcon = document.getElementById('avatar-icon');
    if (avatarIcon) {
        avatarIcon.textContent = personaIcon;
    }

    // Update persona name below avatar
    const personaNameElem = document.getElementById('voice-persona-name');
    if (personaNameElem) {
        personaNameElem.textContent = personaName;
    }

    // Clear transcript
    const transcript = document.getElementById('transcript-messages');
    if (transcript) {
        transcript.innerHTML = '';
    }

    // Show voice controls
    document.getElementById('voice-home-btn').style.display = 'flex';
}

/**
 * Get AI greeting from customer persona
 */
async function getAIGreeting() {
    try {
        const response = await fetch(`http://localhost:8000/api/chat/message`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                message: "Hi, how are you?",
                session_id: voiceCallState.sessionId
            })
        });

        if (!response.ok) throw new Error('Failed to get greeting');
        
        const data = await response.json();
        const aiMessage = data.message;

        // Add to transcript
        addTranscriptMessage('AI', aiMessage);

        // Update tooltip with customer message
        updateCustomerTooltip(aiMessage);

        // Speak the greeting
        speakMessage(aiMessage);

        console.log('[Voice Call] AI greeting:', aiMessage);
    } catch (error) {
        console.error('[Voice Call] Error getting greeting:', error);
    }
}

/**
 * Update customer message tooltip
 */
function updateCustomerTooltip(message) {
    const tooltip = document.getElementById('tooltip-text');
    if (tooltip) {
        tooltip.textContent = message;
        
        // Trigger animation
        const tooltipElem = document.getElementById('customer-tooltip');
        tooltipElem.style.animation = 'none';
        setTimeout(() => {
            tooltipElem.style.animation = 'tooltip-pop 0.4s cubic-bezier(0.34, 1.56, 0.64, 1)';
        }, 10);
    }
}

/**
 * Toggle voice input (Press and hold to speak)
 */
function toggleVoiceInput() {
    console.log('[Voice Call] toggleVoiceInput called - isListening:', voiceCallState.isListening);
    
    if (!voiceCallState.recognition) {
        console.error('[Voice Call] ❌ Speech Recognition not available');
        alert('Speech Recognition not supported in this browser');
        return;
    }

    if (!voiceCallState.isListening) {
        console.log('[Voice Call] Starting listening...');
        startListening();
    } else {
        console.log('[Voice Call] Stopping listening...');
        stopListening();
    }
}

/**
 * Start listening to user
 */
function startListening() {
    if (!voiceCallState.isCallActive || !voiceCallState.recognition) {
        console.error('[Voice Call] Cannot start listening - no active call or recognition');
        return;
    }
    
    console.log('[Voice Call] ========== STARTING TO LISTEN ==========');
    voiceCallState.isListening = true;
    const speakBtn = document.getElementById('speak-btn');
    if (speakBtn) speakBtn.classList.add('speaking');
    updateCallStatus('Listening...');

    // Set up handlers BEFORE calling start()
    voiceCallState.recognition.onstart = () => {
        console.log('[Voice Call] ✅ LISTENING ACTIVE - Please speak now');
    };

    voiceCallState.recognition.onresult = async (event) => {
        console.log('[Voice Call] onresult fired - event:', event);
        console.log('[Voice Call] isFinal:', event.isFinal, 'resultIndex:', event.resultIndex, 'results.length:', event.results.length);
        
        let transcript = '';
        
        // Get the transcript from results
        for (let i = event.resultIndex; i < event.results.length; i++) {
            const transcriptPart = event.results[i][0].transcript;
            console.log('[Voice Call] Result[' + i + ']:', transcriptPart);
            transcript += transcriptPart + ' ';
        }
        
        transcript = transcript.trim();
        console.log('[Voice Call] Final transcript assembled:', transcript, 'isFinal:', event.isFinal);
        
        // Only process final results
        if (event.isFinal) {
            if (transcript.length > 0) {
                console.log('[Voice Call] ✅ FINAL RESULT - Sending:', transcript);
                stopListening();
                
                // Send to AI
                await sendUserMessage(transcript);
            } else {
                console.warn('[Voice Call] Final result but empty transcript - retrying');
                updateCallStatus('No speech detected - try again');
            }
        } else {
            console.log('[Voice Call] Interim result:', transcript);
        }
    };

    voiceCallState.recognition.onerror = (event) => {
        console.error('[Voice Call] ❌ RECOGNITION ERROR:', event.error);
        voiceCallState.isListening = false;
        const speakBtn = document.getElementById('speak-btn');
        if (speakBtn) speakBtn.classList.remove('speaking');
        updateCallStatus('Error: ' + event.error);
    };

    voiceCallState.recognition.onend = () => {
        console.log('[Voice Call] 📴 Recognition ended');
        voiceCallState.isListening = false;
        const speakBtn = document.getElementById('speak-btn');
        if (speakBtn) speakBtn.classList.remove('speaking');
        if (voiceCallState.isCallActive) {
            updateCallStatus('Connected');
        }
    };

    // NOW call start() with handlers already set up
    try {
        console.log('[Voice Call] Calling recognition.start()');
        voiceCallState.recognition.start();
        console.log('[Voice Call] recognition.start() called successfully');
    } catch (e) {
        console.error('[Voice Call] ❌ Error calling recognition.start():', e);
        updateCallStatus('Failed to start listening');
    }
}

/**
 * Stop listening
 */
function stopListening() {
    if (voiceCallState.recognition) {
        voiceCallState.recognition.stop();
    }
}

/**
 * Send user message to AI
 */
async function sendUserMessage(userText) {
    if (!userText || !voiceCallState.sessionId) {
        console.error('[Voice Call] Cannot send message - missing text or session ID');
        return;
    }

    try {
        console.log('[Voice Call] 📤 Sending message to backend:', { userText, sessionId: voiceCallState.sessionId });

        // Add user message to transcript immediately
        addTranscriptMessage('User', userText);
        updateCallStatus('AI Thinking...');

        // Use the api.js sendChatMessage function
        const result = await sendChatMessage(userText, { sessionId: voiceCallState.sessionId });

        console.log('[Voice Call] ✅ AI response received:', result);

        if (!result.success) {
            throw new Error(result.error || 'Failed to get AI response');
        }
        
        const aiMessage = result.data.message;

        // Add AI response to transcript
        addTranscriptMessage('AI', aiMessage);

        // Update tooltip with customer message
        updateCustomerTooltip(aiMessage);

        // Speak the response
        console.log('[Voice Call] 🔊 Speaking AI response...');
        speakMessage(aiMessage);

        updateCallStatus('Connected');
        console.log('[Voice Call] ✅ Full message cycle complete');
    } catch (error) {
        console.error('[Voice Call] ❌ Error sending message:', error);
        updateCallStatus('Error: ' + error.message);
        addTranscriptMessage('System', 'Error: ' + error.message);
    }
}

/**
 * Speak message using Web Speech API
 */
function speakMessage(text) {
    if (!('speechSynthesis' in window)) {
        console.error('[Voice Call] ❌ Speech Synthesis not supported in this browser');
        updateCallStatus('TTS not supported');
        return;
    }

    console.log('[Voice Call] Creating utterance for:', text.substring(0, 50) + '...');
    
    // Cancel any previous speech
    window.speechSynthesis.cancel();
    
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    utterance.volume = 1.0;
    utterance.lang = 'en-US';

    utterance.onstart = () => {
        console.log('[Voice Call] 🔊 Speech synthesis started');
        voiceCallState.isSpeaking = true;
        const avatarPulse = document.getElementById('avatar-pulse');
        if (avatarPulse) avatarPulse.style.opacity = '1';
        document.getElementById('call-status-text').textContent = 'Speaking...';
    };

    utterance.onend = () => {
        console.log('[Voice Call] ✅ Speech synthesis ended');
        voiceCallState.isSpeaking = false;
        const avatarPulse = document.getElementById('avatar-pulse');
        if (avatarPulse) avatarPulse.style.opacity = '0.5';
        updateCallStatus('Connected - Speak again');
    };

    utterance.onerror = (event) => {
        console.error('[Voice Call] ❌ Speech synthesis error:', event.error);
        voiceCallState.isSpeaking = false;
        updateCallStatus('TTS Error: ' + event.error);
    };

    console.log('[Voice Call] Calling speechSynthesis.speak()');
    window.speechSynthesis.speak(utterance);
}

/**
 * Add message to transcript (only show last AI message)
 */
function addTranscriptMessage(speaker, message) {
    const container = document.getElementById('transcript-messages');
    if (!container) return;

    // If AI message, clear previous messages and show only the last one
    if (speaker.toLowerCase() === 'ai') {
        container.innerHTML = '';  // Clear all previous messages
    }

    const messageElem = document.createElement('div');
    messageElem.className = `transcript-message ${speaker.toLowerCase()}`;
    
    const labelElem = document.createElement('div');
    labelElem.className = 'transcript-label';
    labelElem.textContent = speaker;
    
    const contentElem = document.createElement('div');
    contentElem.textContent = message;
    
    messageElem.appendChild(labelElem);
    messageElem.appendChild(contentElem);
    
    container.appendChild(messageElem);
    container.scrollTop = container.scrollHeight;
}

/**
 * Escape HTML to prevent XSS
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

/**
 * Update call status display
 */
function updateCallStatus(status) {
    const statusElem = document.getElementById('call-status-text');
    if (statusElem) {
        statusElem.textContent = status;
    }
}

/**
 * Start call timer
 */
function startCallTimer() {
    if (voiceCallState.callTimer) clearInterval(voiceCallState.callTimer);

    voiceCallState.callTimer = setInterval(() => {
        const elapsed = Math.floor((Date.now() - voiceCallState.callStartTime) / 1000);
        const minutes = Math.floor(elapsed / 60);
        const seconds = elapsed % 60;
        document.getElementById('call-duration').textContent = 
            `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
    }, 1000);
}

/**
 * End voice call and evaluate
 */
async function endVoiceCall() {
    if (!voiceCallState.sessionId) return;

    voiceCallState.isCallActive = false;
    if (voiceCallState.callTimer) clearInterval(voiceCallState.callTimer);

    try {
        // End session and get evaluation
        const response = await fetch(`http://localhost:8000/api/sessions/${voiceCallState.sessionId}/end`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        });

        if (response.ok) {
            const data = await response.json();
            // Store evaluation and go to evaluation screen
            window.sessionData.evaluation = data;
            goToScreen('evaluation');
        }
    } catch (error) {
        console.error('[Voice Call] Error ending call:', error);
    }
}

/**
 * Toggle transcript panel visibility
 */
function toggleTranscriptPanel() {
    const panel = document.getElementById('transcript-panel');
    if (panel) {
        panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
    }
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', () => {
    console.log('[Voice Call] Page loaded, ready for calls');
});
