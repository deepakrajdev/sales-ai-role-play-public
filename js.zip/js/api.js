/**
 * ================================================
 * API.JS - Real Backend API Integration (FIXED)
 * ================================================
 * Connects to Python FastAPI backend
 */

// Backend API Base URL
const API_BASE_URL = 'http://localhost:8000';

/**
 * Fetch all policies from backend
 * Endpoint: GET /api/policies
 */
async function fetchPolicies() {
    console.log('[API] Fetching policies from backend...');

    try {
        const response = await fetch(`${API_BASE_URL}/api/policies`);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const policies = await response.json();
        
        console.log('[API] Policies fetched:', policies);
        
        return {
            success: true,
            data: policies.map(policy => ({
                id: policy.filename,
                name: policy.display_name,
                filename: policy.filename,
                size: policy.file_size || 'Unknown'
            }))
        };
    } catch (error) {
        console.error('[API] Error fetching policies:', error);
        return {
            success: false,
            error: error.message
        };
    }
}

/**
 * Fetch all personas from backend
 * Endpoint: GET /api/personas
 */
async function fetchPersonas() {
    console.log('[API] Fetching personas from backend...');

    try {
        const response = await fetch(`${API_BASE_URL}/api/personas`);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const personasData = await response.json();
        
        console.log('[API] Personas fetched:', personasData);
        
        // Transform backend format to frontend format
        const personas = {};
        for (const [key, value] of Object.entries(personasData)) {
            personas[key] = {
                id: key,
                name: value.display_name,
                traits: value.default_traits
            };
        }
        
        return {
            success: true,
            data: personas
        };
    } catch (error) {
        console.error('[API] Error fetching personas:', error);
        return {
            success: false,
            error: error.message
        };
    }
}

/**
 * Start a new training session
 * Endpoint: POST /api/sessions/start
 */
async function startSession(config) {
    console.log('[API] Starting session with config:', config);

    try {
        const requestBody = {
            mode: "practice_pitch",
            policy: config.policyFilename || "iSelect Smart 360 Term Plan.pdf",
            persona: config.persona,
            traits: config.traits
        };

        console.log('[API] Request body:', requestBody);

        const response = await fetch(`${API_BASE_URL}/api/sessions/start`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(requestBody)
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
        }

        const sessionData = await response.json();
        
        console.log('[API] Session started:', sessionData);

        return {
            success: true,
            data: {
                sessionId: sessionData.session_id,
                startTime: sessionData.started_at,
                config: sessionData
            }
        };
    } catch (error) {
        console.error('[API] Error starting session:', error);
        return {
            success: false,
            error: error.message
        };
    }
}

/**
 * Get session status
 * Endpoint: GET /api/sessions/{session_id}/status
 */
async function getSessionStatus(sessionId) {
    console.log('[API] Getting session status:', sessionId);

    try {
        const response = await fetch(`${API_BASE_URL}/api/sessions/${sessionId}/status`);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const sessionData = await response.json();
        
        return {
            success: true,
            data: sessionData
        };
    } catch (error) {
        console.error('[API] Error getting session status:', error);
        return {
            success: false,
            error: error.message
        };
    }
}

/**
 * Send chat message to AI (FIXED - Now uses REAL backend endpoint)
 * Endpoint: POST /api/chat/message
 */
async function sendChatMessage(message, context) {
    console.log('[API] Sending chat message to REAL backend:', message);
    console.log('[API] Session ID:', window.sessionData?.sessionId);

    try {
        if (!window.sessionData || !window.sessionData.sessionId) {
            throw new Error('No active session found');
        }

        const requestBody = {
            message: message,
            session_id: window.sessionData.sessionId
        };

        console.log('[API] Request body:', requestBody);

        const response = await fetch(`${API_BASE_URL}/api/chat/message`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(requestBody)
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        
        console.log('[API] AI response received:', data);

        return {
            success: true,
            data: {
                message: data.message,
                timestamp: data.timestamp
            }
        };
    } catch (error) {
        console.error('[API] Error sending chat message:', error);
        return {
            success: false,
            error: error.message,
            data: {
                message: "I'm sorry, I encountered an error. Please try again.",
                timestamp: new Date().toISOString()
            }
        };
    }
}

/**
 * End training session and get evaluation
 * Endpoint: POST /api/sessions/{session_id}/end
 */
async function endSessionAPI(sessionId) {
    console.log('[API] Ending session:', sessionId);

    try {
        const response = await fetch(`${API_BASE_URL}/api/sessions/${sessionId}/end`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            }
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const evaluationData = await response.json();
        
        console.log('[API] Evaluation received:', evaluationData);

        return {
            success: true,
            data: {
                sessionId: evaluationData.session_id,
                endTime: evaluationData.evaluated_at,
                evaluation: evaluationData
            }
        };
    } catch (error) {
        console.error('[API] Error ending session:', error);
        return {
            success: false,
            error: error.message
        };
    }
}

/**
 * Get evaluation for a completed session
 * Endpoint: GET /api/sessions/{session_id}/evaluation
 */
async function getEvaluation(sessionId) {
    console.log('[API] Getting evaluation:', sessionId);

    try {
        const response = await fetch(`${API_BASE_URL}/api/sessions/${sessionId}/evaluation`);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const evaluationData = await response.json();
        
        return {
            success: true,
            data: evaluationData
        };
    } catch (error) {
        console.error('[API] Error getting evaluation:', error);
        return {
            success: false,
            error: error.message
        };
    }
}

/**
 * Format backend evaluation data for frontend UI
 */
function formatEvaluationForUI(backendEval) {
    return {
        overall: backendEval.scores.overall,
        details: {
            product: backendEval.scores.product_explanation,
            communication: backendEval.scores.communication_skills,
            objection: backendEval.scores.objection_handling,
            engagement: backendEval.scores.engagement
        },
        strengths: backendEval.feedback.key_strengths,
        improvements: backendEval.feedback.areas_of_improvement
    };
}

/**
 * Check if backend is reachable
 */
async function checkBackendHealth() {
    try {
        const response = await fetch(`${API_BASE_URL}/`, {
            method: 'GET',
            mode: 'cors'
        });
        const data = await response.json();
        console.log('[API] Backend health check:', data);
        return data.status === 'online';
    } catch (error) {
        console.error('[API] Backend not reachable:', error);
        return false;
    }
}

// Check backend health on load
window.addEventListener('DOMContentLoaded', async () => {
    console.log('[API] Checking backend connection...');
    const isHealthy = await checkBackendHealth();
    if (!isHealthy) {
        console.warn('[API] ⚠️ Backend server is not running!');
        console.warn('[API] Please start the backend server: python main.py');
        showToast('⚠️ Backend server is not running! Please start it with: python main.py', 'error');
    } else {
        console.log('[API] ✅ Backend server is running');
        showToast('✅ Connected to backend server', 'success');
    }
});