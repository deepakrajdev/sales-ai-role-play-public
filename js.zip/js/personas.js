/**
 * ================================================
 * PERSONAS.JS - AI Customer Persona Configuration
 * UPDATED: Load personas from backend dynamically
 * ================================================
 */

// Frontend display data (icons, colors, descriptions)
// Traits will be loaded from backend
const PERSONA_DISPLAY_DATA = {
    doctor: {
        id: 'doctor',
        name: 'Doctor',
        icon: 'D',
        color: 'icon-cyan',
        description: 'Busy, practical, risk-aware',
        behavior: 'Asks smart but short questions, dislikes fluff.'
    },
    hr_head: {
        id: 'hr_head',
        name: 'HR Head',
        icon: 'H',
        color: 'icon-purple',
        description: 'People-focused, comparison-driven',
        behavior: 'Compares options, focuses on value & clarity.'
    },
    lawyer: {
        id: 'lawyer',
        name: 'Lawyer',
        icon: 'L',
        color: 'icon-red',
        description: 'Highly critical, detail-obsessed',
        behavior: 'Tests confidence, consistency, and compliance.'
    },
    judge: {
        id: 'judge',
        name: 'Judge',
        icon: 'J',
        color: 'icon-blue',
        description: 'Balanced, authoritative',
        behavior: 'Listens silently, then asks one powerful question.'
    },
    police_officer: {
        id: 'police_officer',
        name: 'Police Officer',
        icon: 'P',
        color: 'icon-green',
        description: 'Direct, skeptical',
        behavior: 'Questions intent and credibility.'
    },
    ias_officer: {
        id: 'ias_officer',
        name: 'IAS Officer',
        icon: 'I',
        color: 'icon-orange',
        description: 'Strategic, calm, deeply analytical',
        behavior: 'Evaluates long-term value and clarity.'
    }
};

// Will be populated from backend
let PERSONAS = {};
let BACKEND_PERSONAS_LOADED = false;

// Trait display names and colors
const TRAIT_CONFIG = {
    intelligence: {
        label: 'Intelligence',
        description: 'Logical reasoning, sharpness of questions',
        color: '#4A5BD9'
    },
    knowledge: {
        label: 'Knowledge',
        description: 'Domain awareness, policy & financial understanding',
        color: '#28C76F'
    },
    verbosity: {
        label: 'Verbosity',
        description: 'How much the customer talks / asks',
        color: '#FF9F43'
    },
    aggressiveness: {
        label: 'Aggressiveness',
        description: 'Pressure, challenging tone, skepticism',
        color: '#EA5455'
    },
    patience: {
        label: 'Patience',
        description: 'Willingness to listen before reacting',
        color: '#7367F0'
    }
};

/**
 * Load personas from backend
 */
async function loadPersonasFromBackend() {
    console.log('[PERSONAS] Loading from backend...');
    
    try {
        const response = await fetchPersonas();
        
        if (response.success) {
            // Merge backend traits with frontend display data
            PERSONAS = {};
            for (const [key, backendData] of Object.entries(response.data)) {
                const displayData = PERSONA_DISPLAY_DATA[key];
                if (displayData) {
                    PERSONAS[key] = {
                        ...displayData,
                        traits: backendData.traits
                    };
                }
            }
            
            BACKEND_PERSONAS_LOADED = true;
            console.log('[PERSONAS] Loaded from backend:', PERSONAS);
            return true;
        } else {
            console.error('[PERSONAS] Failed to load from backend:', response.error);
            // Fall back to hardcoded traits
            useFallbackPersonas();
            return false;
        }
    } catch (error) {
        console.error('[PERSONAS] Error loading from backend:', error);
        useFallbackPersonas();
        return false;
    }
}

/**
 * Use fallback hardcoded personas if backend fails
 */
function useFallbackPersonas() {
    console.warn('[PERSONAS] Using fallback hardcoded traits');
    
    const fallbackTraits = {
        doctor: {
            intelligence: 8,
            knowledge: 7,
            verbosity: 4,
            aggressiveness: 3,
            patience: 5
        },
        hr_head: {
            intelligence: 7,
            knowledge: 6,
            verbosity: 6,
            aggressiveness: 4,
            patience: 7
        },
        lawyer: {
            intelligence: 9,
            knowledge: 8,
            verbosity: 7,
            aggressiveness: 7,
            patience: 4
        },
        judge: {
            intelligence: 9,
            knowledge: 7,
            verbosity: 3,
            aggressiveness: 5,
            patience: 8
        },
        police_officer: {
            intelligence: 6,
            knowledge: 5,
            verbosity: 5,
            aggressiveness: 6,
            patience: 4
        },
        ias_officer: {
            intelligence: 9,
            knowledge: 8,
            verbosity: 6,
            aggressiveness: 5,
            patience: 9
        }
    };
    
    PERSONAS = {};
    for (const [key, displayData] of Object.entries(PERSONA_DISPLAY_DATA)) {
        PERSONAS[key] = {
            ...displayData,
            traits: fallbackTraits[key]
        };
    }
}

/**
 * Ensure personas are loaded before use
 */
async function ensurePersonasLoaded() {
    if (!BACKEND_PERSONAS_LOADED) {
        await loadPersonasFromBackend();
    }
    return PERSONAS;
}

/**
 * Get all personas as an array
 */
async function getAllPersonas() {
    await ensurePersonasLoaded();
    return Object.values(PERSONAS);
}

/**
 * Get a specific persona by ID
 */
async function getPersonaById(id) {
    await ensurePersonasLoaded();
    return PERSONAS[id] || null;
}

/**
 * Get trait configuration
 */
function getTraitConfig() {
    return TRAIT_CONFIG;
}

/**
 * Generate trait bars HTML for a persona
 */
function generateTraitBarsHTML(traits) {
    let html = '';
    for (const [key, value] of Object.entries(traits)) {
        const config = TRAIT_CONFIG[key];
        const percentage = value * 10;
        html += `
            <div class="trait-bar trait-${key}">
                <span class="trait-label">${config.label}</span>
                <div class="trait-progress">
                    <div class="trait-fill" style="width: ${percentage}%;"></div>
                </div>
                <span class="trait-value">${value}</span>
            </div>
        `;
    }
    return html;
}

/**
 * Generate persona card HTML
 */
function generatePersonaCardHTML(persona) {
    return `
        <div class="card persona-card" data-persona="${persona.id}" onclick="selectPersona(this)">
            <div class="persona-avatar ${persona.color}">
                ${persona.icon}
            </div>
            <h3 class="persona-name">${persona.name}</h3>
            <p class="persona-desc">${persona.description}</p>
            <div class="trait-bars">
                ${generateTraitBarsHTML(persona.traits)}
            </div>
        </div>
    `;
}

/**
 * Generate trait editor controls HTML
 */
function generateTraitEditorHTML(traits) {
    let html = '';
    for (const [key, value] of Object.entries(traits)) {
        const config = TRAIT_CONFIG[key];
        html += `
            <div class="trait-edit-row">
                <div class="trait-edit-label">
                    <div>${config.label}</div>
                    <small style="color: var(--text-muted); font-weight: 400;">${config.description}</small>
                </div>
                <div class="trait-slider-container">
                    <input type="range" class="trait-slider" id="trait-${key}" 
                           min="1" max="10" value="${value}" 
                           oninput="updateTraitValue('${key}', this.value)">
                    <input type="number" class="trait-number" id="trait-${key}-value" 
                           min="1" max="10" value="${value}" readonly>
                </div>
            </div>
        `;
    }
    return html;
}

/**
 * Update trait value display
 */
function updateTraitValue(traitKey, value) {
    document.getElementById(`trait-${traitKey}-value`).value = value;
    
    // Update session data
    if (window.sessionData && window.sessionData.customTraits) {
        window.sessionData.customTraits[traitKey] = parseInt(value);
        console.log('[PERSONAS] Trait updated:', traitKey, '=', value);
    }
}

/**
 * Get current custom traits from editor
 */
function getCustomTraits() {
    const traits = {};
    for (const key of Object.keys(TRAIT_CONFIG)) {
        const slider = document.getElementById(`trait-${key}`);
        if (slider) {
            traits[key] = parseInt(slider.value);
        }
    }
    return traits;
}

// Load personas from backend on script load
(async function() {
    console.log('[PERSONAS] Initializing...');
    await loadPersonasFromBackend();
    console.log('[PERSONAS] Ready');
})();