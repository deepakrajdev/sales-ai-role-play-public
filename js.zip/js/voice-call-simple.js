/**
 * ================================================
 * VOICE-CALL-SIMPLE.JS - Voice Call Interface
 * Based on working voice-call.js logic
 * ================================================
 */

// Voice call state
let callStartTime = null;
let callTimerInterval = null;
let conversationTranscript = [];
let isMuted = false;
let isRecording = false;
let transcriptStartTime = null;
let lastAIMessage = ''; // Store last AI message for display

// Speech recognition setup
let recognition = null;
if ('webkitSpeechRecognition' in window) {
    recognition = new webkitSpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';
} else if ('SpeechRecognition' in window) {
    recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';
}

console.log('[VOICE] Speech Recognition available:', !!recognition);

/**
 * Start voice call
 */
async function startVoiceCall() {
    console.log('[VOICE] === START VOICE CALL ===');
    console.log('[VOICE] Session data:', window.sessionData);
    
    // Check if session data exists
    if (!window.sessionData) {
        alert('Please complete the setup first.');
        return;
    }

    // Get persona - handle both object and string formats
    let personaId = null;
    let personaName = null;
    let personaIcon = null;

    if (window.sessionData.persona) {
        // Persona is an object with id, name, icon
        personaId = window.sessionData.persona.id;
        personaName = window.sessionData.persona.name;
        personaIcon = window.sessionData.persona.icon;
    } else if (window.sessionData.personaId) {
        // Persona stored as personaId
        personaId = window.sessionData.personaId;
        personaName = window.sessionData.personaName || 'Customer';
        personaIcon = window.sessionData.personaIcon || '👤';
    }

    // Validate persona
    if (!personaId) {
        console.error('[VOICE] No persona found. Session data:', window.sessionData);
        alert('Please select a persona first.');
        return;
    }

    try {
        console.log('[VOICE] Creating backend session...');
        
        // Create session on backend
        const payload = {
            mode: 'practice_pitch',
            policy: window.sessionData.policyFilename || 'iSelect Smart 360 Term Plan.pdf',
            persona: personaId,
            traits: window.sessionData.customTraits || window.sessionData.traits || { intelligence: 5, knowledge: 5, verbosity: 5, aggressiveness: 5, patience: 5 }
        };

        console.log('[VOICE] Session payload:', payload);

        const response = await fetch('http://localhost:8000/api/sessions/start', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.detail || 'Session creation failed');
        }

        const data = await response.json();
        console.log('[VOICE] ✓ Session created:', data);

        // Store session ID
        window.sessionData.sessionId = data.session_id;
        conversationTranscript = [];

        // Clear transcript UI
        const transcriptContent = document.getElementById('transcript-content');
        if (transcriptContent) {
            transcriptContent.innerHTML = '';
        }

        // Update UI
        const avatarElem = document.getElementById('call-avatar');
        if (avatarElem) {
            const icon = avatarElem.querySelector('.avatar-icon');
            if (icon) icon.textContent = personaIcon || '👤';
        }
        
        const nameElem = document.getElementById('call-persona-name');
        if (nameElem) nameElem.textContent = personaName || 'Customer';

        const policyElem = document.getElementById('call-policy-name');
        if (policyElem) policyElem.textContent = payload.policy;
        
        updateCallStatus('Connecting...');

        // Navigate to call screen
        goToScreen('voice-call');

        // Mark call as active
        window.isCallActive = true;

        // Start call timer
        startCallTimer();

        console.log('[VOICE] ✓ Call started with session:', window.sessionData.sessionId);

        // Get AI's greeting (salesperson initiates)
        await getAIGreeting();

    } catch (error) {
        console.error('[VOICE] ✗ Start call error:', error);
        alert('Failed to start call: ' + error.message);
    }
}

/**
 * Get AI's initial greeting from salesperson
 */
async function getAIGreeting() {
    console.log('[VOICE] Getting AI greeting...');
    
    try {
        updateCallStatus('Agent is connecting...');

        // Send empty first message to get AI greeting
        const response = await fetch('http://localhost:8000/api/chat/message', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                message: '',
                session_id: window.sessionData.sessionId
            })
        });

        if (!response.ok) {
            throw new Error('Failed to get greeting');
        }

        const data = await response.json();
        const aiMessage = data.message;

        console.log('[VOICE] ✓ AI greeting:', aiMessage);

        addToTranscript('ai', aiMessage);
        
        // Show greeting in speech bubble
        showSpeechBubble(aiMessage);
        
        speakText(aiMessage);

        updateCallStatus('Listening...');

    } catch (error) {
        console.error('[VOICE] Error getting AI greeting:', error);
        updateCallStatus('Listening...');
    }
}

/**
 * Toggle voice input (press to speak)
 */
function toggleVoiceInput() {
    if (!recognition) {
        alert('Speech recognition not supported in your browser');
        return;
    }

    if (isRecording) {
        stopVoiceInput();
    } else {
        startVoiceInput();
    }
}

/**
 * Start listening to user
 */
function startVoiceInput() {
    console.log('[VOICE] Starting voice input...');
    
    if (!recognition || isMuted) return;

    isRecording = true;
    const voiceBtn = document.getElementById('speak-btn');
    if (voiceBtn) voiceBtn.classList.add('recording');

    updateCallStatus('You are speaking...');

    recognition.start();

    recognition.onresult = async (event) => {
        const transcript = event.results[0][0].transcript;
        console.log('[VOICE] User said:', transcript);

        // Add to transcript
        addToTranscript('user', transcript);

        // Send to AI and get response
        await sendUserMessage(transcript);
    };

    recognition.onerror = (event) => {
        console.error('[VOICE] Recognition error:', event.error);
        updateCallStatus('Error listening. Try again.');
        stopVoiceInput();
    };

    recognition.onend = () => {
        stopVoiceInput();
    };
}

/**
 * Stop listening
 */
function stopVoiceInput() {
    isRecording = false;
    const voiceBtn = document.getElementById('speak-btn');
    if (voiceBtn) voiceBtn.classList.remove('recording');

    if (recognition) {
        recognition.stop();
    }
}

/**
 * Send user message to AI
 */
async function sendUserMessage(userText) {
    console.log('[VOICE] Sending user message:', userText);
    
    try {
        updateCallStatus('Agent is thinking...');

        const response = await fetch('http://localhost:8000/api/chat/message', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                message: userText,
                session_id: window.sessionData.sessionId
            })
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.detail || 'Failed to send message');
        }

        const data = await response.json();
        const aiMessage = data.message;

        console.log('[VOICE] ✓ AI Response:', aiMessage);

        // Add to transcript
        addToTranscript('ai', aiMessage);
        
        // Show message in speech bubble
        showSpeechBubble(aiMessage);

        // Speak the response
        speakText(aiMessage);

        updateCallStatus('Listening...');
    } catch (error) {
        console.error('[VOICE] Error sending message:', error);
        updateCallStatus('Error. Try again.');
    }
}

/**
 * Add message to transcript
 */
function addToTranscript(speaker, message) {
    const now = new Date();
    const time = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
    
    console.log('[VOICE] Adding to transcript -', speaker + ':', message.substring(0, 50) + '...');
    
    conversationTranscript.push({
        time,
        speaker,
        message
    });

    // Update live transcript UI - try both possible element IDs
    let transcriptElement = document.getElementById('transcript-messages');
    if (!transcriptElement) {
        transcriptElement = document.getElementById('transcript-content');
    }
    
    if (transcriptElement) {
        const line = document.createElement('div');
        line.className = `transcript-line ${speaker}`;
        line.innerHTML = `
            <span class="transcript-time">${time}</span>
            <span class="transcript-speaker">${speaker === 'ai' ? 'Agent' : 'You'}</span>
            <span class="transcript-text">${escapeHtml(message)}</span>
        `;
        transcriptElement.appendChild(line);
        transcriptElement.scrollTop = transcriptElement.scrollHeight;

        console.log('[VOICE] ✓ Message added to:', transcriptElement.id);
    } else {
        console.warn('[VOICE] ✗ Transcript element not found (checked transcript-messages and transcript-content)');
    }
}

/**
 * Escape HTML to prevent XSS
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

/**
 * Speak text using Web Speech API
 */
function speakText(text) {
    console.log('[VOICE] Speaking:', text.substring(0, 50) + '...');
    
    if ('speechSynthesis' in window) {
        // Cancel any ongoing speech
        window.speechSynthesis.cancel();

        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 1.0;
        utterance.pitch = 1.0;
        utterance.volume = 1.0;
        utterance.lang = 'en-US';

        // Select a good English voice
        const voices = window.speechSynthesis.getVoices();
        console.log('[VOICE] Available voices:', voices.length);
        
        const englishVoice = voices.find(voice => voice.lang.includes('en'));
        if (englishVoice) {
            utterance.voice = englishVoice;
            console.log('[VOICE] Using voice:', englishVoice.name);
        }

        // Show speaking animation
        const avatar = document.getElementById('call-avatar');
        if (avatar) {
            avatar.classList.add('speaking');
            console.log('[VOICE] Avatar showing speaking animation');
        }

        utterance.onstart = () => {
            console.log('[VOICE] Speech started');
        };

        utterance.onend = () => {
            console.log('[VOICE] Speech ended');
            if (avatar) avatar.classList.remove('speaking');
        };

        utterance.onerror = (error) => {
            console.error('[VOICE] Speech synthesis error:', error);
            if (avatar) avatar.classList.remove('speaking');
        };

        console.log('[VOICE] Calling speechSynthesis.speak()');
        window.speechSynthesis.speak(utterance);
    } else {
        console.error('[VOICE] Speech synthesis not supported in this browser');
    }
}

/**
 * Update call status
 */
function updateCallStatus(status) {
    const statusElem = document.getElementById('call-status-text');
    const roleElem = document.getElementById('call-persona-role');

    if (statusElem) {
        statusElem.textContent = status;
    }

    if (roleElem) {
        roleElem.textContent = status;
    }
}

/**
 * Show AI message in speech bubble
 */
function showSpeechBubble(message) {
    console.log('[VOICE] Adding message to transcript column:', message.substring(0, 50) + '...');
    
    lastAIMessage = message;
    
    // The message is already added to transcript in addToTranscript()
    // So it will appear in the transcript-content column automatically
    // No need for a separate speech bubble
}

/**
 * Start call timer
 */
function startCallTimer() {
    console.log('[VOICE] Starting call timer...');
    callStartTime = Date.now();
    callTimerInterval = setInterval(updateCallTimer, 1000);
}

/**
 * Stop call timer
 */
function stopCallTimer() {
    console.log('[VOICE] Stopping call timer...');
    if (callTimerInterval) {
        clearInterval(callTimerInterval);
        callTimerInterval = null;
    }
}

/**
 * Update call timer display
 */
function updateCallTimer() {
    if (!callStartTime) return;

    const elapsed = Math.floor((Date.now() - callStartTime) / 1000);
    const minutes = Math.floor(elapsed / 60);
    const seconds = elapsed % 60;

    const timerElement = document.getElementById('call-timer');
    if (timerElement) {
        timerElement.textContent = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
    }
}

/**
 * End voice call - shows confirmation modal instead of native confirm dialog
 */
function endVoiceCall() {
    console.log('[VOICE] End call button clicked');
    
    if (!window.isCallActive) return;

    // Show custom modal instead of browser confirm
    showEndCallModal();
}

/**
 * Display evaluation after call
 */
function displayEvaluation(evaluation) {
    console.log('[VOICE] === DISPLAYING EVALUATION ===');
    console.log('[VOICE] Evaluation object:', evaluation);
    
    goToScreen('evaluation');

    // Get scores (handle various response formats)
    const scores = evaluation.scores || evaluation;
    
    console.log('[VOICE] Scores:', scores);

    // Display overall score
    const overallElem = document.getElementById('overall-score');
    if (overallElem) {
        const score = scores.overall || scores.score || 0;
        overallElem.textContent = score;
        console.log('[VOICE] Set overall-score to:', score);
    } else {
        console.warn('[VOICE] overall-score element not found');
    }

    // Display detailed scores
    const scoreIds = ['score-product', 'score-communication', 'score-objection', 'score-engagement'];
    const scoreKeys = ['product_explanation', 'communication_skills', 'objection_handling', 'engagement'];
    
    scoreIds.forEach((id, index) => {
        const elem = document.getElementById(id);
        if (elem) {
            const score = scores[scoreKeys[index]] || 0;
            elem.textContent = score;
            console.log('[VOICE] Set', id, 'to:', score);
        } else {
            console.warn('[VOICE]', id, 'element not found');
        }
    });

    // Display strengths
    const strengthsList = document.getElementById('strengths-list');
    console.log('[VOICE] Strengths list element:', strengthsList);
    console.log('[VOICE] Evaluation feedback:', evaluation.feedback);
    
    if (strengthsList) {
        strengthsList.innerHTML = '';
        const strengths = evaluation.feedback?.key_strengths || [];
        console.log('[VOICE] Strengths to display:', strengths);
        
        if (strengths.length === 0) {
            console.warn('[VOICE] No strengths found in evaluation');
            const li = document.createElement('li');
            li.textContent = 'No strengths recorded';
            strengthsList.appendChild(li);
        } else {
            strengths.forEach(strength => {
                const li = document.createElement('li');
                li.textContent = strength;
                strengthsList.appendChild(li);
                console.log('[VOICE] Added strength:', strength);
            });
        }
    } else {
        console.warn('[VOICE] strengths-list element not found');
    }

    // Display improvements
    const improvementsList = document.getElementById('improvements-list');
    console.log('[VOICE] Improvements list element:', improvementsList);
    
    if (improvementsList) {
        improvementsList.innerHTML = '';
        const improvements = evaluation.feedback?.areas_of_improvement || [];
        console.log('[VOICE] Improvements to display:', improvements);
        
        if (improvements.length === 0) {
            console.warn('[VOICE] No improvements found in evaluation');
            const li = document.createElement('li');
            li.textContent = 'No improvements recorded';
            improvementsList.appendChild(li);
        } else {
            improvements.forEach(improvement => {
                const li = document.createElement('li');
                li.textContent = improvement;
                improvementsList.appendChild(li);
                console.log('[VOICE] Added improvement:', improvement);
            });
        }
    } else {
        console.warn('[VOICE] improvements-list element not found');
    }

    // Display transcript
    displayTranscript();

    console.log('[VOICE] ✓ Evaluation displayed');
}

/**
 * Display full transcript
 */
function displayTranscript() {
    const transcriptContainer = document.getElementById('full-transcript');
    if (!transcriptContainer) return;

    transcriptContainer.innerHTML = '';

    if (!conversationTranscript || conversationTranscript.length === 0) {
        transcriptContainer.innerHTML = '<p style="color: var(--text-muted);">No conversation recorded.</p>';
        return;
    }

    conversationTranscript.forEach(msg => {
        const messageDiv = document.createElement('div');
        messageDiv.className = `transcript-message ${msg.speaker}`;

        const speaker = msg.speaker === 'user' ? 'SALESPERSON' : 'CUSTOMER';
        const speakerLabel = document.createElement('div');
        speakerLabel.className = 'transcript-speaker';
        speakerLabel.textContent = `${speaker} (${msg.time})`;

        const content = document.createElement('div');
        content.className = 'transcript-content';
        content.textContent = msg.message;

        messageDiv.appendChild(speakerLabel);
        messageDiv.appendChild(content);
        transcriptContainer.appendChild(messageDiv);
    });
}

/**
 * Toggle mute
 */
function toggleMute() {
    isMuted = !isMuted;
    const muteBtn = document.getElementById('mute-btn');

    if (isMuted) {
        muteBtn.classList.add('muted');
        muteBtn.querySelector('span').textContent = '🔇';
        updateCallStatus('Muted');
    } else {
        muteBtn.classList.remove('muted');
        muteBtn.querySelector('span').textContent = '🎤';
        updateCallStatus('Listening...');
    }

    console.log('[VOICE] Muted:', isMuted);
}
/**
 * Download transcript as text file
 */
function downloadTranscript() {
    console.log('[VOICE] Downloading transcript...');
    
    if (!voiceState.transcript || voiceState.transcript.length === 0) {
        alert('No transcript to download');
        return;
    }

    let transcriptText = '=== CALL TRANSCRIPT ===\n\n';

    voiceState.transcript.forEach((msg, index) => {
        const speaker = msg.speaker === 'You' ? 'YOU (Salesperson)' : 'CUSTOMER (AI)';
        transcriptText += `${speaker}:\n${msg.message}\n\n`;
    });

    const blob = new Blob([transcriptText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `transcript-${Date.now()}.txt`;
    a.click();

    URL.revokeObjectURL(url);
    console.log('[VOICE] Transcript downloaded');
}

/**
 * Start new session (go back to home)
 */
function startNewSession() {
    console.log('[VOICE] === STARTING NEW SESSION ===');
    
    try {
        // Stop any ongoing speech
        if (window.speechSynthesis) {
            window.speechSynthesis.cancel();
        }
        
        // Stop any ongoing recording
        if (recognition && isRecording) {
            recognition.stop();
        }
        
        // Stop call timer
        stopCallTimer();
        
        // Reset state
        conversationTranscript = [];
        lastAIMessage = '';
        isMuted = false;
        isRecording = false;
        callStartTime = null;
        
        if (window.sessionData) {
            window.sessionData.sessionId = null;
        }
        
        window.isCallActive = false;
        
        console.log('[VOICE] ✓ Session reset, going home...');
        
        // Navigate home
        goHome();
    } catch (error) {
        console.error('[VOICE] Error starting new session:', error);
        alert('Error: ' + error.message);
    }
}

// Ensure voices are loaded for speech synthesis
if ('speechSynthesis' in window) {
    console.log('[VOICE] Loading voices...');
    window.speechSynthesis.onvoiceschanged = () => {
        const voices = window.speechSynthesis.getVoices();
        console.log('[VOICE] ✓ Voices loaded:', voices.length, 'voices available');
    };
    
    // Try to load voices immediately
    try {
        const voices = window.speechSynthesis.getVoices();
        console.log('[VOICE] Voices available:', voices.length);
    } catch (e) {
        console.log('[VOICE] Voices not immediately available');
    }
}

/**
 * Show custom end call confirmation modal
 */
function showEndCallModal() {
    const modal = document.getElementById('end-call-modal');
    if (modal) {
        modal.style.display = 'flex';
        // Pause voice input while modal is open
        if (window.recognition && window.isRecording) {
            window.recognition.stop();
        }
    }
}

/**
 * Hide end call confirmation modal
 */
function hideEndCallModal() {
    const modal = document.getElementById('end-call-modal');
    if (modal) {
        modal.style.display = 'none';
    }
}

/**
 * Cancel end call confirmation
 */
function cancelEndCall() {
    console.log('[VOICE] End call cancelled');
    hideEndCallModal();
    // Resume voice input if call is still active
    if (window.isCallActive && window.recognition) {
        // Don't automatically resume - let user click Speak button
        updateCallStatus('Ready to listen');
    }
}

/**
 * Confirm end call and proceed with termination
 */
async function confirmEndCall() {
    console.log('[VOICE] End call confirmed');
    hideEndCallModal();

    if (!window.isCallActive) return;

    try {
        // Stop any ongoing speech
        if (window.speechSynthesis) {
            window.speechSynthesis.cancel();
        }

        // Stop call timer
        stopCallTimer();

        // Mark call as inactive
        window.isCallActive = false;

        // End backend session
        const response = await fetch(`http://localhost:8000/api/sessions/${window.sessionData.sessionId}/end`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        });

        if (response.ok) {
            const result = await response.json();
            console.log('[VOICE] ✓ Call ended, showing evaluation');
            
            // Store transcript in session data for evaluation display
            window.sessionData.messages = conversationTranscript;

            // Navigate to evaluation
            displayEvaluation(result.scores || result);
        } else {
            alert('Error ending session');
            goHome();
        }
    } catch (error) {
        console.error('[VOICE] Error ending call:', error);
        alert('Error ending call: ' + error.message);
        goHome();
    }
}