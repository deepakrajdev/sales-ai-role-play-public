/**
 * ================================================
 * VOICE.JS - Real-time Voice Call System
 * ================================================
 * Handles browser audio recording, streaming, and playback
 */

// Voice system state
let voiceState = {
    isActive: false,
    isMuted: false,
    isRecording: false,
    mediaRecorder: null,
    audioContext: null,
    audioStream: null,
    audioChunks: [],
    sessionId: null,
    callStartTime: null,
    callTimer: null,
    transcript: [],
    turnCount: 0
};

/**
 * Start voice session
 */
async function startVoiceSession() {
    console.log('[VOICE] Starting voice session...');
    
    if (!window.sessionData || !window.sessionData.persona) {
        showToast('Please select a persona first', 'error');
        return;
    }

    // Ensure policy is loaded
    if (!window.sessionData.policyFilename) {
        showLoading('Loading policies...');
        await loadPoliciesFromBackend();
        hideLoading();
        
        if (!window.sessionData.policyFilename) {
            showToast('No policies available. Please add PDFs to backend.', 'error');
            return;
        }
    }

    // Navigate to voice call screen
    goToScreen('voice-call');
    
    // Initialize voice call
    await initializeVoiceCall();
}

/**
 * Initialize voice call interface
 */
async function initializeVoiceCall() {
    console.log('[VOICE] Initializing voice call...');
    
    const persona = window.sessionData.persona;
    
    // Update UI
    document.getElementById('voice-avatar-icon').textContent = persona.icon;
    document.getElementById('voice-persona-name').textContent = `${persona.name} (Customer)`;
    document.getElementById('voice-persona-role').textContent = persona.description;
    
    // Reset transcript
    voiceState.transcript = [];
    voiceState.turnCount = 0;
    document.getElementById('transcript-content').innerHTML = '';
    
    // Update status
    updateVoiceStatus('Initializing voice system...', 'warning');
    
    try {
        // Start backend session
        showLoading('Starting voice session...');
        
        const response = await startSession({
            persona: persona.id,
            traits: window.sessionData.customTraits,
            policyFilename: window.sessionData.policyFilename
        });
        
        hideLoading();
        
        if (!response.success) {
            throw new Error(response.error || 'Failed to start session');
        }
        
        voiceState.sessionId = response.data.sessionId;
        window.sessionData.sessionId = response.data.sessionId;
        
        console.log('[VOICE] Session started:', voiceState.sessionId);
        
        // Request microphone access
        updateVoiceStatus('Requesting microphone access...', 'warning');
        await requestMicrophoneAccess();
        
        // Start the call
        await startCall();
        
    } catch (error) {
        console.error('[VOICE] Error initializing:', error);
        updateVoiceStatus('Failed to start voice session: ' + error.message, 'error');
        showToast('Voice session failed: ' + error.message, 'error');
    }
}

/**
 * Request microphone access
 */
async function requestMicrophoneAccess() {
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ 
            audio: {
                echoCancellation: true,
                noiseSuppression: true,
                autoGainControl: true
            } 
        });
        
        voiceState.audioStream = stream;
        console.log('[VOICE] Microphone access granted');
        
        return true;
    } catch (error) {
        console.error('[VOICE] Microphone access denied:', error);
        throw new Error('Microphone access is required for voice calls');
    }
}

/**
 * Start the actual call
 */
async function startCall() {
    console.log('[VOICE] Starting call...');
    
    // Update UI
    document.getElementById('call-status').textContent = 'Connected';
    document.getElementById('call-btn').classList.add('active');
    updateVoiceStatus('Call connected - Start speaking!', 'success');
    
    // Start call timer
    voiceState.callStartTime = Date.now();
    startCallTimer();
    
    // Add initial greeting to transcript
    addTranscriptMessage('system', 'Call connected. AI will greet you shortly...');
    
    // Get AI greeting
    await getAIGreeting();
    
    // Start continuous recording
    startContinuousRecording();
    
    voiceState.isActive = true;
}

/**
 * Get AI greeting
 */
async function getAIGreeting() {
    try {
        // Use first message as greeting trigger
        const response = await sendChatMessage('Hello', {
            persona: window.sessionData.persona.id,
            traits: window.sessionData.customTraits,
            policyFilename: window.sessionData.policyFilename
        });
        
        if (response.success && response.data.message) {
            // Add to transcript
            addTranscriptMessage('ai', response.data.message);
            
            // Speak the greeting
            await speakText(response.data.message);
            
            // Activate voice wave
            showVoiceWave('ai');
        }
    } catch (error) {
        console.error('[VOICE] Error getting greeting:', error);
        addTranscriptMessage('system', 'Error getting AI greeting');
    }
}

/**
 * Start continuous recording with Voice Activity Detection
 */
function startContinuousRecording() {
    if (!voiceState.audioStream) {
        console.error('[VOICE] No audio stream available');
        return;
    }
    
    console.log('[VOICE] Starting continuous recording...');
    
    // Create MediaRecorder
    const options = {
        mimeType: 'audio/webm;codecs=opus',
        audioBitsPerSecond: 16000
    };
    
    voiceState.mediaRecorder = new MediaRecorder(voiceState.audioStream, options);
    voiceState.audioChunks = [];
    
    // Handle data available
    voiceState.mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
            voiceState.audioChunks.push(event.data);
        }
    };
    
    // Handle recording stop
    voiceState.mediaRecorder.onstop = async () => {
        if (voiceState.audioChunks.length > 0) {
            console.log('[VOICE] Processing recorded audio...');
            await processRecordedAudio();
        }
    };
    
    // Start recording in chunks (every 3 seconds)
    voiceState.mediaRecorder.start();
    voiceState.isRecording = true;
    
    // Set up automatic chunking
    setInterval(() => {
        if (voiceState.isRecording && voiceState.mediaRecorder.state === 'recording') {
            voiceState.mediaRecorder.stop();
            voiceState.audioChunks = [];
            voiceState.mediaRecorder.start();
        }
    }, 3000); // Process every 3 seconds
}

/**
 * Process recorded audio
 */
async function processRecordedAudio() {
    if (voiceState.audioChunks.length === 0) return;
    
    try {
        // Create audio blob
        const audioBlob = new Blob(voiceState.audioChunks, { type: 'audio/webm' });
        
        // Convert to text using Web Speech API
        const text = await transcribeAudio(audioBlob);
        
        if (text && text.trim().length > 0) {
            console.log('[VOICE] User said:', text);
            
            // Add to transcript
            addTranscriptMessage('user', text);
            
            // Show user speaking
            showVoiceWave('user');
            
            // Get AI response
            await getAIResponse(text);
        }
        
    } catch (error) {
        console.error('[VOICE] Error processing audio:', error);
    }
}

/**
 * Transcribe audio using Web Speech API
 */
async function transcribeAudio(audioBlob) {
    return new Promise((resolve, reject) => {
        // For now, we'll use a simpler approach with SpeechRecognition
        // In production, this would send to backend Whisper API
        
        if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
            // Fallback: simulate transcription
            console.warn('[VOICE] Speech recognition not available, using fallback');
            resolve(''); // Return empty to skip this chunk
            return;
        }
        
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        const recognition = new SpeechRecognition();
        
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'en-US';
        
        recognition.onresult = (event) => {
            const transcript = event.results[0][0].transcript;
            resolve(transcript);
        };
        
        recognition.onerror = (event) => {
            console.error('[VOICE] Recognition error:', event.error);
            resolve(''); // Return empty on error
        };
        
        recognition.onnomatch = () => {
            resolve('');
        };
        
        // Create audio element to play for recognition
        const audioUrl = URL.createObjectURL(audioBlob);
        const audio = new Audio(audioUrl);
        
        audio.onplay = () => {
            recognition.start();
        };
        
        audio.onended = () => {
            setTimeout(() => {
                recognition.stop();
            }, 500);
        };
        
        audio.play();
    });
}

/**
 * Get AI response
 */
async function getAIResponse(userMessage) {
    try {
        showVoiceWave('ai');
        updateVoiceStatus('AI is thinking...', 'warning');
        
        const response = await sendChatMessage(userMessage, {
            persona: window.sessionData.persona.id,
            traits: window.sessionData.customTraits,
            policyFilename: window.sessionData.policyFilename
        });
        
        if (response.success && response.data.message) {
            const aiMessage = response.data.message;
            
            // Add to transcript
            addTranscriptMessage('ai', aiMessage);
            
            // Speak the response
            await speakText(aiMessage);
            
            updateVoiceStatus('Listening...', 'success');
        } else {
            throw new Error(response.error || 'Failed to get AI response');
        }
        
        hideVoiceWave();
        
    } catch (error) {
        console.error('[VOICE] Error getting AI response:', error);
        updateVoiceStatus('Error: ' + error.message, 'error');
        hideVoiceWave();
    }
}

/**
 * Speak text using Web Speech API
 */
async function speakText(text) {
    return new Promise((resolve, reject) => {
        if (!('speechSynthesis' in window)) {
            console.warn('[VOICE] Speech synthesis not available');
            resolve();
            return;
        }
        
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 1.0;
        utterance.pitch = 1.0;
        utterance.volume = 1.0;
        
        // Get a voice (prefer English voices)
        const voices = speechSynthesis.getVoices();
        const englishVoice = voices.find(v => v.lang.startsWith('en')) || voices[0];
        if (englishVoice) {
            utterance.voice = englishVoice;
        }
        
        utterance.onend = () => {
            console.log('[VOICE] Finished speaking');
            resolve();
        };
        
        utterance.onerror = (error) => {
            console.error('[VOICE] Speech error:', error);
            reject(error);
        };
        
        showVoiceWave('ai');
        speechSynthesis.speak(utterance);
        
        // Hide wave when done
        utterance.onend = () => {
            hideVoiceWave();
            resolve();
        };
    });
}

/**
 * Add message to transcript
 */
function addTranscriptMessage(speaker, text) {
    voiceState.turnCount++;
    
    const timestamp = formatCallTime(Date.now() - voiceState.callStartTime);
    const transcriptEntry = {
        speaker: speaker,
        text: text,
        timestamp: timestamp,
        time: Date.now()
    };
    
    voiceState.transcript.push(transcriptEntry);
    
    // Update UI
    const transcriptContainer = document.getElementById('transcript-content');
    const messageDiv = document.createElement('div');
    messageDiv.className = `transcript-message ${speaker}`;
    
    const speakerLabel = speaker === 'user' ? 'You' : 
                        speaker === 'ai' ? window.sessionData.persona.name :
                        'System';
    
    messageDiv.innerHTML = `
        <span class="transcript-time">${timestamp}</span>
        <span class="transcript-speaker">${speakerLabel}:</span>
        <span class="transcript-text">${text}</span>
    `;
    
    transcriptContainer.appendChild(messageDiv);
    transcriptContainer.scrollTop = transcriptContainer.scrollHeight;
}

/**
 * Show voice wave animation
 */
function showVoiceWave(type) {
    const waveContainer = document.getElementById('voice-wave');
    waveContainer.classList.add('active');
    
    if (type === 'ai') {
        waveContainer.style.filter = 'hue-rotate(0deg)';
    } else {
        waveContainer.style.filter = 'hue-rotate(120deg)';
    }
}

/**
 * Hide voice wave animation
 */
function hideVoiceWave() {
    const waveContainer = document.getElementById('voice-wave');
    waveContainer.classList.remove('active');
}

/**
 * Start call timer
 */
function startCallTimer() {
    const timerDisplay = document.getElementById('call-timer');
    
    voiceState.callTimer = setInterval(() => {
        const elapsed = Date.now() - voiceState.callStartTime;
        timerDisplay.textContent = formatCallTime(elapsed);
    }, 1000);
}

/**
 * Format call time
 */
function formatCallTime(ms) {
    const totalSeconds = Math.floor(ms / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
}

/**
 * Toggle mute
 */
function toggleMute() {
    voiceState.isMuted = !voiceState.isMuted;
    
    const muteBtn = document.getElementById('mute-btn');
    const btnIcon = muteBtn.querySelector('.btn-icon');
    
    if (voiceState.isMuted) {
        muteBtn.classList.add('muted');
        btnIcon.textContent = '🔇';
        
        // Mute audio stream
        if (voiceState.audioStream) {
            voiceState.audioStream.getAudioTracks().forEach(track => {
                track.enabled = false;
            });
        }
        
        updateVoiceStatus('Microphone muted', 'warning');
    } else {
        muteBtn.classList.remove('muted');
        btnIcon.textContent = '🎤';
        
        // Unmute audio stream
        if (voiceState.audioStream) {
            voiceState.audioStream.getAudioTracks().forEach(track => {
                track.enabled = true;
            });
        }
        
        updateVoiceStatus('Microphone active', 'success');
    }
}

/**
 * Toggle call (pause/resume)
 */
function toggleCall() {
    const callBtn = document.getElementById('call-btn');
    
    if (voiceState.isRecording) {
        // Pause recording
        voiceState.isRecording = false;
        if (voiceState.mediaRecorder && voiceState.mediaRecorder.state === 'recording') {
            voiceState.mediaRecorder.pause();
        }
        callBtn.classList.remove('active');
        updateVoiceStatus('Call paused', 'warning');
    } else {
        // Resume recording
        voiceState.isRecording = true;
        if (voiceState.mediaRecorder && voiceState.mediaRecorder.state === 'paused') {
            voiceState.mediaRecorder.resume();
        }
        callBtn.classList.add('active');
        updateVoiceStatus('Call resumed', 'success');
    }
}

/**
 * End voice call
 */
async function endVoiceCall() {
    console.log('[VOICE] Ending call...');
    
    // Stop timer
    if (voiceState.callTimer) {
        clearInterval(voiceState.callTimer);
    }
    
    // Stop recording
    voiceState.isRecording = false;
    if (voiceState.mediaRecorder) {
        voiceState.mediaRecorder.stop();
    }
    
    // Stop audio stream
    if (voiceState.audioStream) {
        voiceState.audioStream.getTracks().forEach(track => track.stop());
    }
    
    // Stop any ongoing speech
    if ('speechSynthesis' in window) {
        speechSynthesis.cancel();
    }
    
    voiceState.isActive = false;
    
    // Get evaluation
    showLoading('Generating evaluation...');
    
    try {
        const response = await endSessionAPI(voiceState.sessionId);
        
        if (response.success) {
            window.sessionData.evaluation = response.data.evaluation;
            window.sessionData.transcript = voiceState.transcript;
            window.sessionData.duration = Date.now() - voiceState.callStartTime;
            
            hideLoading();
            
            // Navigate to evaluation
            goToScreen('evaluation');
            loadEvaluation();
        } else {
            throw new Error(response.error || 'Failed to get evaluation');
        }
    } catch (error) {
        console.error('[VOICE] Error ending call:', error);
        hideLoading();
        showToast('Error getting evaluation: ' + error.message, 'error');
        
        // Still go to evaluation with mock data
        goToScreen('evaluation');
        displayMockEvaluation();
    }
}

/**
 * Update voice status
 */
function updateVoiceStatus(message, type = 'success') {
    const statusText = document.getElementById('status-text');
    const statusIndicator = document.querySelector('.status-indicator');
    
    statusText.textContent = message;
    
    // Update status type
    statusIndicator.classList.remove('error', 'warning');
    if (type === 'error' || type === 'warning') {
        statusIndicator.classList.add(type);
    }
}

/**
 * Toggle transcript visibility
 */
function toggleTranscript() {
    const container = document.querySelector('.voice-transcript-container');
    container.classList.toggle('collapsed');
}

/**
 * Load evaluation with transcript
 */
function loadEvaluation() {
    if (!window.sessionData || !window.sessionData.evaluation) {
        console.error('[VOICE] No evaluation data');
        return;
    }
    
    const evaluation = formatEvaluationForUI(window.sessionData.evaluation);
    
    // Display scores
    displayEvaluation(evaluation);
    
    // Display meta info
    const duration = window.sessionData.duration || 0;
    document.getElementById('eval-duration').textContent = formatCallTime(duration);
    document.getElementById('eval-turns').textContent = voiceState.turnCount;
    
    // Display full transcript
    displayFullTranscript(window.sessionData.transcript || voiceState.transcript);
}

/**
 * Display full transcript in evaluation
 */
function displayFullTranscript(transcript) {
    const container = document.getElementById('full-transcript');
    
    if (!transcript || transcript.length === 0) {
        container.innerHTML = '<p style="color: var(--text-muted); text-align: center;">No transcript available</p>';
        return;
    }
    
    let html = '';
    
    transcript.forEach(entry => {
        const speakerLabel = entry.speaker === 'user' ? 'SALESPERSON' :
                            entry.speaker === 'ai' ? 'CUSTOMER' :
                            'SYSTEM';
        
        const speakerClass = entry.speaker === 'user' ? 'user' : '';
        
        html += `
            <div class="transcript-entry">
                <span class="timestamp">[${entry.timestamp}]</span>
                <span class="speaker-label ${speakerClass}">${speakerLabel}:</span>
                <div class="message-text">${entry.text}</div>
            </div>
        `;
    });
    
    container.innerHTML = html;
}

/**
 * Download transcript
 */
function downloadTranscript() {
    const transcript = window.sessionData.transcript || voiceState.transcript;
    
    if (!transcript || transcript.length === 0) {
        showToast('No transcript to download', 'error');
        return;
    }
    
    let text = `VOICE TRAINING SESSION TRANSCRIPT\n`;
    text += `=====================================\n\n`;
    text += `Persona: ${window.sessionData.persona.name}\n`;
    text += `Date: ${new Date().toLocaleString()}\n`;
    text += `Duration: ${document.getElementById('eval-duration').textContent}\n`;
    text += `Turns: ${voiceState.turnCount}\n\n`;
    text += `CONVERSATION:\n`;
    text += `=====================================\n\n`;
    
    transcript.forEach(entry => {
        const speaker = entry.speaker === 'user' ? 'SALESPERSON' :
                       entry.speaker === 'ai' ? 'CUSTOMER' :
                       'SYSTEM';
        
        text += `[${entry.timestamp}] ${speaker}:\n${entry.text}\n\n`;
    });
    
    // Create download
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `transcript_${voiceState.sessionId}_${Date.now()}.txt`;
    a.click();
    
    showToast('Transcript downloaded', 'success');
}

// Ensure speech synthesis voices are loaded
if ('speechSynthesis' in window) {
    speechSynthesis.onvoiceschanged = () => {
        console.log('[VOICE] Speech synthesis voices loaded');
    };
}