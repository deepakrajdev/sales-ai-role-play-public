/**
 * ================================================
 * NAVIGATION.JS - Updated with Home Button & Start Call Page
 * ================================================
 */

/**
 * Navigate to a specific screen
 */
function goToScreen(screenId) {
    // Hide all screens
    document.querySelectorAll('.screen').forEach(screen => {
        screen.classList.remove('active');
    });

    // Show target screen
    const targetScreen = document.getElementById(screenId);
    if (targetScreen) {
        targetScreen.classList.add('active');

        // Update home button visibility
        updateHomeButton(screenId);

        // Scroll to top
        window.scrollTo(0, 0);

        console.log('[NAV] Navigated to:', screenId);
    }
}

/**
 * Update home button visibility based on current screen
 */
function updateHomeButton(screenId) {
    const homeBtn = document.getElementById('home-btn');
    if (homeBtn) {
        // Hide home button only on persona-selection screen
        if (screenId === 'persona-selection') {
            homeBtn.style.display = 'none';
        } else {
            homeBtn.style.display = 'flex';
        }
    }
}

/**
 * Go to home page
 */
function goHome() {
    // If in an active call, confirm first
    if (window.isCallActive) {
        if (confirm('Are you sure you want to end the call and return home? Your progress will be lost.')) {
            // End the call if active
            if (typeof endVoiceCall === 'function') {
                window.isCallActive = false; // Prevent confirm dialog from showing again
                endVoiceCall();
            }
            startNewSession();
        }
    } else {
        startNewSession();
    }
}

/**
 * Get persona by ID from display data and backend traits
 */
function getPersonaById(personaId) {
    // Get display data
    const displayData = PERSONA_DISPLAY_DATA[personaId];
    if (!displayData) {
        console.error('[NAV] Persona display data not found:', personaId);
        return null;
    }

    // Define fallback traits for each persona (from backend models)
    const fallbackTraits = {
        doctor: { intelligence: 8, knowledge: 7, verbosity: 4, aggressiveness: 3, patience: 5 },
        hr_head: { intelligence: 7, knowledge: 6, verbosity: 6, aggressiveness: 4, patience: 7 },
        lawyer: { intelligence: 9, knowledge: 8, verbosity: 7, aggressiveness: 7, patience: 4 },
        judge: { intelligence: 9, knowledge: 7, verbosity: 3, aggressiveness: 5, patience: 8 },
        police_officer: { intelligence: 6, knowledge: 5, verbosity: 5, aggressiveness: 6, patience: 4 },
        ias_officer: { intelligence: 9, knowledge: 8, verbosity: 6, aggressiveness: 5, patience: 9 }
    };

    // Get traits - from PERSONAS (if backend loaded) or fallback
    let traits = fallbackTraits[personaId] || {};
    if (PERSONAS && PERSONAS[personaId] && PERSONAS[personaId].default_traits) {
        traits = PERSONAS[personaId].default_traits;
    }
    
    // Combine display data with traits
    return {
        id: personaId,
        name: displayData.name,
        icon: displayData.icon,
        description: displayData.description,
        behavior: displayData.behavior,
        traits: traits,
        color: displayData.color
    };
}

/**
 * Handle persona selection from dropdown
 */
async function onPersonaSelect(personaId) {
    if (!personaId) {
        // Reset if no persona selected
        document.getElementById('main-avatar').querySelector('.avatar-icon').textContent = '👤';
        document.getElementById('avatar-name').textContent = 'Select a Persona';
        document.getElementById('avatar-desc').textContent = 'Choose from the dropdown below to begin';
        return;
    }

    // Get persona from display data and backend traits
    const persona = getPersonaById(personaId);
    if (!persona) {
        console.error('[NAV] Persona not found:', personaId);
        showToast('Failed to load persona data', 'error');
        return;
    }

    console.log('[NAV] Selected persona (from backend):', persona);

    // Update main avatar display
    document.getElementById('main-avatar').querySelector('.avatar-icon').textContent = persona.icon;
    document.getElementById('avatar-name').textContent = persona.name;
    document.getElementById('avatar-desc').textContent = persona.description;

    // Store selected persona in session data with backend traits
    window.sessionData = window.sessionData || {};
    window.sessionData.personaId = personaId; // Store persona ID for API
    window.sessionData.personaName = persona.name; // Store display name
    window.sessionData.personaIcon = persona.icon; // Store emoji icon
    window.sessionData.personaObject = persona; // Keep full object for UI
    window.sessionData.traits = { ...persona.traits }; // Store traits (not customTraits)

    console.log('[NAV] Stored persona with backend traits:', window.sessionData.traits);

    // Navigate to personality page after brief delay
    setTimeout(() => {
        goToPersonalityPage();
    }, 500);
}

/**
 * Navigate to Personality Page and load policies
 */
async function goToPersonalityPage() {
    if (!window.sessionData || !window.sessionData.personaId) {
        alert('Please select a persona first.');
        return;
    }

    goToScreen('personality-page');
    
    // Load personality page with persona
    loadPersonalityPage();
    
    // Load available policies from backend
    await loadPoliciesFromBackend();
}

/**
 * Load policies from real backend
 */
async function loadPoliciesFromBackend() {
    try {
        showLoading('Loading policies...');
        
        const response = await fetchPolicies();
        
        hideLoading();
        
        if (response.success && response.data.length > 0) {
            // Auto-select first policy
            window.sessionData.policyFilename = response.data[0].filename;
            window.sessionData.policyDisplayName = response.data[0].name;
            
            console.log('[NAV] Auto-selected policy:', window.sessionData.policyDisplayName);
        } else {
            console.warn('[NAV] No policies found in backend');
            showToast('No policies available. Please add PDFs to the Policies folder.', 'error');
        }
    } catch (error) {
        console.error('[NAV] Error loading policies:', error);
        hideLoading();
        showToast('Error loading policies from backend', 'error');
    }
}

/**
 * Load Personality Page with selected persona data
 */
function loadPersonalityPage() {
    const persona = window.sessionData.personaObject;
    if (!persona) {
        console.error('[NAV] No persona object found');
        alert('Please select a persona first.');
        return;
    }

    // Update avatar
    document.getElementById('personality-avatar').querySelector('.avatar-icon').textContent = persona.icon;
    document.getElementById('personality-persona-name').textContent = persona.name;
    document.getElementById('personality-behavior').textContent = persona.description;

    // Load traits display (from backend)
    console.log('[NAV] Loading traits from backend:', window.sessionData.traits);
    loadTraitsDisplay(window.sessionData.traits);

    // Load trait editor controls
    loadTraitEditorDropdowns(window.sessionData.traits);

    // Reset editor state
    const editor = document.getElementById('trait-editor');
    editor.classList.remove('active');
    document.getElementById('edit-btn').innerHTML = '<span>✏️</span> Edit Behaviour';
    document.getElementById('start-training-btn').innerHTML = 'Continue <span>→</span>';
}

/**
 * Load traits display with bars
 */
function loadTraitsDisplay(traits) {
    const container = document.getElementById('traits-display');
    const traitConfig = getTraitConfig();

    let html = '';
    for (const [key, value] of Object.entries(traits)) {
        const config = traitConfig[key];
        const percentage = value * 10;
        html += `
            <div class="trait-display-row">
                <span class="trait-display-label">${config.label}</span>
                <div class="trait-display-bar">
                    <div class="trait-display-fill" style="width: ${percentage}%; background: ${config.color};"></div>
                </div>
                <span class="trait-display-value">${value}</span>
            </div>
        `;
    }
    container.innerHTML = html;
}

/**
 * Load trait editor with dropdowns
 */
function loadTraitEditorDropdowns(traits) {
    const container = document.getElementById('trait-controls');
    const traitConfig = getTraitConfig();

    let html = '';
    for (const [key, value] of Object.entries(traits)) {
        const config = traitConfig[key];

        // Generate options 1-10
        let options = '';
        for (let i = 1; i <= 10; i++) {
            const selected = i === value ? 'selected' : '';
            options += `<option value="${i}" ${selected}>${i}</option>`;
        }

        html += `
            <div class="trait-edit-dropdown-row">
                <div class="trait-edit-label">
                    <div>${config.label}</div>
                    <small style="color: var(--text-muted); font-weight: 400;">${config.description}</small>
                </div>
                <select class="trait-dropdown-select" id="trait-${key}" onchange="updateCustomTrait('${key}', this.value)">
                    ${options}
                </select>
            </div>
        `;
    }
    container.innerHTML = html;
}

/**
 * Update custom trait value
 */
function updateCustomTrait(traitKey, value) {
    if (window.sessionData && window.sessionData.traits) {
        window.sessionData.traits[traitKey] = parseInt(value);
        console.log('[NAV] Updated trait:', traitKey, '=', value);
        
        // Also update the display
        loadTraitsDisplay(window.sessionData.traits);
    }
}

/**
 * Toggle trait editor visibility
 */
function toggleTraitEditor() {
    const editor = document.getElementById('trait-editor');
    const editBtn = document.getElementById('edit-btn');
    const startBtn = document.getElementById('start-training-btn');

    if (editor.classList.contains('active')) {
        // Hide editor
        editor.classList.remove('active');
        editBtn.innerHTML = '<span>✏️</span> Edit Behaviour';
        startBtn.innerHTML = 'Continue <span>→</span>';

        // Reset traits to backend default (from personaObject)
        const persona = window.sessionData.personaObject;
        if (persona && persona.traits) {
            window.sessionData.traits = { ...persona.traits };
            loadTraitsDisplay(persona.traits);
            loadTraitEditorDropdowns(persona.traits);
            console.log('[NAV] Reset to backend default traits:', persona.traits);
        }
    } else {
        // Show editor
        editor.classList.add('active');
        editBtn.innerHTML = '<span>✓</span> Done Editing';
        startBtn.innerHTML = 'Continue <span>→</span>';

        // Scroll to editor
        editor.scrollIntoView({ behavior: 'smooth' });
    }
}

/**
 * Go to Start Call Page (NEW)
 */
function goToStartCallPage() {
    if (!window.sessionData || !window.sessionData.personaId) {
        alert('Please select a persona first.');
        return;
    }

    // Ensure we have a policy selected
    if (!window.sessionData.policyFilename) {
        // Try to load policies again
        loadPoliciesFromBackend().then(() => {
            if (window.sessionData.policyFilename) {
                proceedToStartCallPage();
            } else {
                showToast('Please add policy PDFs to the backend Policies folder', 'error');
            }
        });
    } else {
        proceedToStartCallPage();
    }
}

/**
 * Proceed to Start Call Page
 */
function proceedToStartCallPage() {
    const persona = window.sessionData.personaObject;
    
    if (!persona) {
        alert('Please select a persona first.');
        return;
    }
    
    // Update start call page UI
    document.getElementById('start-call-avatar').querySelector('.avatar-icon').textContent = persona.icon;
    document.getElementById('start-call-persona-name').textContent = persona.name;
    
    goToScreen('start-call-page');
    
    console.log('[NAV] Ready to start call with:', persona.name, 'ID:', window.sessionData.personaId);
}

/**
 * Start New Session - Reset everything
 */
function startNewSession() {
    // Reset session data
    window.sessionData = {};
    window.isCallActive = false;

    // Hide trait editor
    const editor = document.getElementById('trait-editor');
    if (editor) {
        editor.classList.remove('active');
    }

    // Navigate to persona selection screen
    goToScreen('persona-selection');

    // Reset dropdown and avatar display
    const dropdown = document.getElementById('persona-dropdown');
    if (dropdown) {
        dropdown.value = '';
    }
    document.getElementById('main-avatar').querySelector('.avatar-icon').textContent = '👤';
    document.getElementById('avatar-name').textContent = 'Select a Persona';
    document.getElementById('avatar-desc').textContent = 'Choose from the dropdown below to begin';

    console.log('[NAV] Started new session');
}