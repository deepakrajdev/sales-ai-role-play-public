/**
 * ================================================
 * VOICE-CALL.JS - Voice-Only Call Interface
 * No text chat UI, only voice interaction with transcript at end
 * ================================================
 */

// Voice call state
let callStartTime = null;
let callTimerInterval = null;
let conversationTranscript = [];
let isMuted = false;
let isRecording = false;
let transcriptStartTime = null;

// Speech recognition setup
let recognition = null;
if ('webkitSpeechRecognition' in window) {
    recognition = new webkitSpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';
} else if ('SpeechRecognition' in window) {
    recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';
}

/**
 * Toggle transcript visibility
 */
function toggleTranscript() {
    const transcript = document.getElementById('call-transcript');
    transcript.classList.toggle('collapsed');
}

/**
 * Update call status
 */
function updateCallStatus(status) {
    document.getElementById('call-persona-role').textContent = status;
}

/**
 * Add message to transcript
 */
function addToTranscript(speaker, message) {
    const now = new Date();
    const time = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
    
    conversationTranscript.push({
        time,
        speaker,
        message
    });

    // Update live transcript UI
    const transcriptContent = document.getElementById('transcript-content');
    if (transcriptContent) {
        const line = document.createElement('div');
        line.className = `transcript-line ${speaker}`;
        line.innerHTML = `
            <span class="transcript-time">${time}</span>
            <span class="transcript-speaker">${speaker === 'ai' ? 'Agent' : 'You'}</span>
            <span class="transcript-text">${escapeHtml(message)}</span>
        `;
        transcriptContent.appendChild(line);
        transcriptContent.scrollTop = transcriptContent.scrollHeight;
    }
}

/**
 * Escape HTML to prevent XSS
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

/**
 * Start voice call
 */
async function startVoiceCall() {
    if (!window.sessionData || !window.sessionData.persona) {
        alert('Please select a persona first.');
        return;
    }

    showLoading('Starting call...');

    try {
        // Start backend session
        const response = await startSession({
            persona: window.sessionData.persona.id,
            traits: window.sessionData.customTraits,
            policyFilename: window.sessionData.policyFilename || 'iSelect Smart 360 Term Plan.pdf'
        });

        hideLoading();

        if (!response.success) {
            showToast('Failed to start session: ' + response.error, 'error');
            return;
        }

        // Store session ID
        window.sessionData.sessionId = response.data.sessionId;
        conversationTranscript = [];

        // Clear transcript UI
        const transcriptContent = document.getElementById('transcript-content');
        if (transcriptContent) {
            transcriptContent.innerHTML = '';
        }

        // Update UI
        const persona = window.sessionData.persona;
        document.getElementById('call-avatar').querySelector('.avatar-icon').textContent = persona.icon;
        document.getElementById('call-persona-name').textContent = persona.name;
        updateCallStatus('Connecting...');

        // Navigate to call screen
        goToScreen('voice-call');

        // Mark call as active
        window.isCallActive = true;

        // Start call timer
        startCallTimer();

        console.log('[VOICE] Call started with session:', window.sessionData.sessionId);

        // Get AI's greeting (salesperson initiates)
        await getAIGreeting();

    } catch (error) {
        hideLoading();
        showToast('Error starting call: ' + error.message, 'error');
        console.error('[VOICE] Start call error:', error);
    }
}

/**
 * Get AI's initial greeting from salesperson
 */
async function getAIGreeting() {
    try {
        updateCallStatus('Agent is connecting...');

        // Send empty first message to get AI greeting
        const response = await sendChatMessage('', {});

        if (response.success) {
            const aiMessage = response.data.message;

            // Add to transcript
            addToTranscript('ai', aiMessage);

            // Speak the greeting
            speakText(aiMessage);

            updateCallStatus('Listening...');
        }
    } catch (error) {
        console.error('[VOICE] Error getting AI greeting:', error);
        updateCallStatus('Listening...');
    }
}

/**
 * Toggle voice input (press to speak)
 */
function toggleVoiceInput() {
    if (!recognition) {
        showToast('Speech recognition not supported in your browser', 'error');
        return;
    }

    if (isRecording) {
        stopVoiceInput();
    } else {
        startVoiceInput();
    }
}

/**
 * Start listening to user
 */
function startVoiceInput() {
    if (!recognition || isMuted) return;

    isRecording = true;
    const voiceBtn = document.getElementById('voice-btn');
    voiceBtn.classList.add('recording');

    updateCallStatus('You are speaking...');

    recognition.start();

    recognition.onresult = async (event) => {
        const transcript = event.results[0][0].transcript;
        console.log('[VOICE] User said:', transcript);

        // Add to transcript
        addToTranscript('user', transcript);

        // Send to AI and get response
        await sendUserMessage(transcript);
    };

    recognition.onerror = (event) => {
        console.error('[VOICE] Recognition error:', event.error);
        updateCallStatus('Error listening. Try again.');
        stopVoiceInput();
    };

    recognition.onend = () => {
        stopVoiceInput();
    };
}

/**
 * Stop listening
 */
function stopVoiceInput() {
    isRecording = false;
    const voiceBtn = document.getElementById('voice-btn');
    voiceBtn.classList.remove('recording');

    if (recognition) {
        recognition.stop();
    }
}

/**
 * Send user message to AI
 */
async function sendUserMessage(userText) {
    try {
        updateCallStatus('Customer is thinking...');

        const response = await sendChatMessage(userText, {});

        if (response.success) {
            const aiMessage = response.data.message;

            // Add to transcript
            addToTranscript('ai', aiMessage);

            // Speak the response
            speakText(aiMessage);

            updateCallStatus('Listening...');
        } else {
            updateCallStatus('Error. Try again.');
            showToast('Error getting response', 'error');
        }
    } catch (error) {
        console.error('[VOICE] Error sending message:', error);
        updateCallStatus('Error. Try again.');
    }
}

/**
 * Speak text using Web Speech API
 */
function speakText(text) {
    if ('speechSynthesis' in window) {
        // Cancel any ongoing speech
        window.speechSynthesis.cancel();

        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 1.0;
        utterance.pitch = 1.0;
        utterance.volume = 1.0;

        // Select a good English voice
        const voices = window.speechSynthesis.getVoices();
        const englishVoice = voices.find(voice => voice.lang.startsWith('en-'));
        if (englishVoice) {
            utterance.voice = englishVoice;
        }

        // Show speaking animation
        const avatar = document.getElementById('call-avatar');
        avatar.classList.add('speaking');

        utterance.onend = () => {
            avatar.classList.remove('speaking');
        };

        updateCallStatus('Customer is speaking...');
        window.speechSynthesis.speak(utterance);
    } else {
        console.warn('[VOICE] Speech synthesis not supported');
    }
}

/**
 * Toggle mute
 */
function toggleMute() {
    isMuted = !isMuted;
    const muteBtn = document.getElementById('mute-btn');

    if (isMuted) {
        muteBtn.classList.add('muted');
        muteBtn.querySelector('span').textContent = '🔇';
        updateCallStatus('Muted');
    } else {
        muteBtn.classList.remove('muted');
        muteBtn.querySelector('span').textContent = '🎤';
        updateCallStatus('Listening...');
    }

    console.log('[VOICE] Muted:', isMuted);
}

/**
 * End voice call
 */
async function endVoiceCall() {
    if (!window.isCallActive) return;

    const confirmed = confirm('Are you sure you want to end the call?');
    if (!confirmed) return;

    showLoading('Ending call and generating evaluation...');

    try {
        // Stop any ongoing speech
        if (window.speechSynthesis) {
            window.speechSynthesis.cancel();
        }

        // Stop call timer
        stopCallTimer();

        // Mark call as inactive
        window.isCallActive = false;

        // End backend session
        const response = await endSessionAPI(window.sessionData.sessionId);

        hideLoading();

        if (response.success) {
            // Store transcript in session data for evaluation display
            window.sessionData.messages = conversationTranscript;

            // Navigate to evaluation
            displayEvaluation(response.data.evaluation);
        } else {
            showToast('Error ending session', 'error');
            goHome();
        }
    } catch (error) {
        hideLoading();
        console.error('[VOICE] Error ending call:', error);
        showToast('Error ending call', 'error');
        goHome();
    }
}

/**
 * Add message to transcript
 */
function addToTranscript(role, text) {
    const time = new Date().toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit'
    });

    conversationTranscript.push({
        role: role,
        content: text,
        time: time
    });

    console.log('[VOICE] Transcript:', conversationTranscript.length, 'messages');
}

/**
 * Update call status display
 */
function updateCallStatus(status) {
    const statusElement = document.getElementById('call-status');
    const roleElement = document.getElementById('call-persona-role');

    if (statusElement) {
        statusElement.querySelector('span:last-child').textContent = status;
    }

    if (roleElement) {
        roleElement.textContent = status;
    }
}

/**
 * Start call timer
 */
function startCallTimer() {
    callStartTime = Date.now();
    callTimerInterval = setInterval(updateCallTimer, 1000);
}

/**
 * Stop call timer
 */
function stopCallTimer() {
    if (callTimerInterval) {
        clearInterval(callTimerInterval);
        callTimerInterval = null;
    }
}

/**
 * Update call timer display
 */
function updateCallTimer() {
    if (!callStartTime) return;

    const elapsed = Math.floor((Date.now() - callStartTime) / 1000);
    const minutes = Math.floor(elapsed / 60);
    const seconds = elapsed % 60;

    const timerElement = document.getElementById('call-timer');
    if (timerElement) {
        timerElement.textContent = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
    }
}

/**
 * Display evaluation after call
 */
function displayEvaluation(evaluation) {
    goToScreen('evaluation');

    // Display scores
    document.getElementById('overall-score').textContent = evaluation.scores.overall;
    document.getElementById('score-product').textContent = evaluation.scores.product_explanation;
    document.getElementById('score-communication').textContent = evaluation.scores.communication_skills;
    document.getElementById('score-objection').textContent = evaluation.scores.objection_handling;
    document.getElementById('score-engagement').textContent = evaluation.scores.engagement;

    // Display strengths
    const strengthsList = document.getElementById('strengths-list');
    strengthsList.innerHTML = '';
    evaluation.feedback.key_strengths.forEach(strength => {
        const li = document.createElement('li');
        li.textContent = strength;
        strengthsList.appendChild(li);
    });

    // Display improvements
    const improvementsList = document.getElementById('improvements-list');
    improvementsList.innerHTML = '';
    evaluation.feedback.areas_of_improvement.forEach(improvement => {
        const li = document.createElement('li');
        li.textContent = improvement;
        improvementsList.appendChild(li);
    });

    // Display transcript
    displayTranscript();

    console.log('[VOICE] Evaluation displayed');
}

/**
 * Display full transcript
 */
function displayTranscript() {
    const transcriptContainer = document.getElementById('full-transcript');
    transcriptContainer.innerHTML = '';

    if (!conversationTranscript || conversationTranscript.length === 0) {
        transcriptContainer.innerHTML = '<p style="color: var(--text-muted);">No conversation recorded.</p>';
        return;
    }

    conversationTranscript.forEach(msg => {
        const messageDiv = document.createElement('div');
        messageDiv.className = `transcript-message ${msg.role}`;

        const speaker = msg.role === 'user' ? 'SALESPERSON' : 'CUSTOMER';
        const speakerLabel = document.createElement('div');
        speakerLabel.className = 'transcript-speaker';
        speakerLabel.textContent = `${speaker} (${msg.time})`;

        const content = document.createElement('div');
        content.className = 'transcript-content';
        content.textContent = msg.content;

        messageDiv.appendChild(speakerLabel);
        messageDiv.appendChild(content);
        transcriptContainer.appendChild(messageDiv);
    });
}

/**
 * Download transcript
 */
function downloadTranscript() {
    if (!conversationTranscript || conversationTranscript.length === 0) {
        showToast('No transcript to download', 'error');
        return;
    }

    let transcriptText = '=== CALL TRANSCRIPT ===\n\n';

    conversationTranscript.forEach(msg => {
        const speaker = msg.role === 'user' ? 'SALESPERSON' : 'CUSTOMER';
        transcriptText += `${speaker} (${msg.time}):\n${msg.content}\n\n`;
    });

    const blob = new Blob([transcriptText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `transcript-${Date.now()}.txt`;
    a.click();

    URL.revokeObjectURL(url);
    showToast('Transcript downloaded', 'success');
}

// Ensure voices are loaded for speech synthesis
if ('speechSynthesis' in window) {
    window.speechSynthesis.onvoiceschanged = () => {
        const voices = window.speechSynthesis.getVoices();
        console.log('[VOICE] Available voices:', voices.length);
    };
}