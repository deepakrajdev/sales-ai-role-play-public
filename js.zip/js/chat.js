let chatTimer = null;
let chatSeconds = 0;
let chatMessages = [];

// Simple voice state
let voiceEnabled = false;
let isListening = false;
let isSpeaking = false;
let recognition = null;
let synthesis = window.speechSynthesis;

/**
 * Initialize chat interface
 */
async function initializeChat() {
    const session = window.sessionData;
    const persona = session.persona;

    // Update session info sidebar
    document.getElementById('session-persona').textContent = persona.name;

    // Update chat header
    document.getElementById('chat-avatar').textContent = persona.icon;
    document.getElementById('chat-persona-name').textContent = `${persona.name} (Customer)`;

    // Update traits display
    const traitsContainer = document.getElementById('session-traits');
    traitsContainer.innerHTML = generateTraitBarsHTML(session.customTraits);

    // Clear previous messages
    chatMessages = [];
    document.getElementById('chat-messages').innerHTML = '';

    // Reset timer
    chatSeconds = 0;
    updateTimerDisplay();
    startTimer();

    // Initialize voice if available
    initializeVoice();

    // Show loading while starting session
    showLoading('Starting training session...');

    // Start session via REAL backend API
    await startSessionAPI();

    hideLoading();

    // Add initial AI greeting
    setTimeout(() => {
        const greeting = getPersonaGreeting(persona.id);
        addAIMessage(greeting);
        
        // Speak greeting if voice is enabled
        if (voiceEnabled) {
            speakMessage(greeting);
        }
    }, 1000);
}

function initializeVoice() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    
    if (!SpeechRecognition) {
        console.warn('[VOICE] Speech recognition not supported');
        voiceEnabled = false;
        return;
    }

    // Initialize recognition
    recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onstart = () => {
        isListening = true;
        updateVoiceButton('listening');
        console.log('[VOICE] Listening...');
    };

    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        console.log('[VOICE] Heard:', transcript);
        
        // Send the recognized text as a message
        if (transcript && transcript.trim().length > 0) {
            sendMessage(transcript);
        }
    };

    recognition.onerror = (event) => {
        console.error('[VOICE] Recognition error:', event.error);
        isListening = false;
        updateVoiceButton('ready');
    };

    recognition.onend = () => {
        isListening = false;
        updateVoiceButton('ready');
        console.log('[VOICE] Stopped listening');
    };

    voiceEnabled = true;
    updateVoiceButton('ready');
    console.log('[VOICE] Voice enabled');
}

/**
 * Start session API call (REAL BACKEND)
 */
async function startSessionAPI() {
    try {
        const response = await startSession({
            persona: window.sessionData.persona.id,
            traits: window.sessionData.customTraits,
            policyFilename: window.sessionData.policyFilename || null
        });

        if (response.success) {
            window.sessionData.sessionId = response.data.sessionId;
            window.sessionData.backendSession = response.data.config;
            console.log('[CHAT] Real session started:', response.data.sessionId);
            showToast('Session started successfully!', 'success');
        } else {
            throw new Error(response.error || 'Failed to start session');
        }
    } catch (error) {
        console.error('[CHAT] Error starting session:', error);
        showToast('Error starting session: ' + error.message, 'error');
        
        // Fallback: continue with mock session
        window.sessionData.sessionId = 'fallback_' + Date.now();
    }
}

/**
 * Get persona-specific greeting
 */
function getPersonaGreeting(personaId) {
    const greetings = {
        doctor: "Hello. I understand you want to discuss insurance plans. I have about 10 minutes before my next appointment, so let's be quick.",
        hr_head: "Good day. We're looking to update our employee benefits package. I'd like to understand what options you have for group coverage.",
        lawyer: "I've been reviewing some insurance options. Before we proceed, I'd like to understand the exact terms and conditions of your policies.",
        judge: "Proceed. Tell me about your insurance offerings.",
        police_officer: "So you're an insurance agent? What are you trying to sell me today?",
        ias_officer: "Thank you for meeting with me. I'm looking for a comprehensive insurance solution with long-term value. Please walk me through your offerings."
    };

    return greetings[personaId] || "Hello, I'm interested in learning about your insurance policies.";
}

/**
 * Start session timer
 */
function startTimer() {
    if (chatTimer) {
        clearInterval(chatTimer);
    }

    chatTimer = setInterval(() => {
        chatSeconds++;
        updateTimerDisplay();
    }, 1000);
}

/**
 * Update timer display
 */
function updateTimerDisplay() {
    const minutes = Math.floor(chatSeconds / 60);
    const seconds = chatSeconds % 60;
    const display = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    document.getElementById('session-timer').textContent = display;
}

/**
 * Add AI message to chat
 */
function addAIMessage(text) {
    const messagesContainer = document.getElementById('chat-messages');
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const messageDiv = document.createElement('div');
    messageDiv.className = 'message ai';
    messageDiv.innerHTML = `
        ${text}
        <div class="message-time">${time}</div>
    `;

    messagesContainer.appendChild(messageDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;

    chatMessages.push({ role: 'ai', content: text, time: time });
}

/**
 * Add user message to chat
 */
function addUserMessage(text) {
    const messagesContainer = document.getElementById('chat-messages');
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const messageDiv = document.createElement('div');
    messageDiv.className = 'message user';
    messageDiv.innerHTML = `
        ${text}
        <div class="message-time">${time}</div>
    `;

    messagesContainer.appendChild(messageDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;

    chatMessages.push({ role: 'user', content: text, time: time });
}

/**
 * Add typing indicator
 */
function showTypingIndicator() {
    const messagesContainer = document.getElementById('chat-messages');

    const typingDiv = document.createElement('div');
    typingDiv.className = 'message ai';
    typingDiv.id = 'typing-indicator';
    typingDiv.innerHTML = `
        <div class="typing-indicator">
            <span></span>
            <span></span>
            <span></span>
        </div>
    `;

    messagesContainer.appendChild(typingDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

/**
 * Remove typing indicator
 */
function hideTypingIndicator() {
    const indicator = document.getElementById('typing-indicator');
    if (indicator) {
        indicator.remove();
    }
}

/**
 * Send message (works for both text input and voice input)
 */
async function sendMessage(messageText) {
    let text;
    
    // If messageText is provided (from voice), use it
    // Otherwise, get from input field
    if (messageText) {
        text = messageText.trim();
    } else {
        const input = document.getElementById('chat-input');
        text = input.value.trim();
        input.value = '';
    }

    if (!text) return;

    // Add user message
    addUserMessage(text);

    // Show typing indicator
    showTypingIndicator();

    // Get AI response
    try {
        const response = await sendChatMessage(text, {
            persona: window.sessionData.persona.id,
            traits: window.sessionData.customTraits,
            policyFilename: window.sessionData.policyFilename
        });

        hideTypingIndicator();

        if (response.success) {
            const aiMessage = response.data.message;
            addAIMessage(aiMessage);
            
            // Speak AI response if voice is enabled
            if (voiceEnabled && !isSpeaking) {
                await speakMessage(aiMessage);
            }
        }
    } catch (error) {
        hideTypingIndicator();
        console.error('[CHAT] Error sending message:', error);
        addAIMessage("I'm sorry, I didn't quite catch that. Could you please repeat?");
    }
}

/**
 * Speak a message using text-to-speech
 */
async function speakMessage(text) {
    return new Promise((resolve, reject) => {
        if (!synthesis) {
            resolve();
            return;
        }

        // Stop any ongoing speech
        synthesis.cancel();

        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 0.95;
        utterance.pitch = 1.0;
        utterance.volume = 1.0;

        // Try to get a good English voice
       const voices = synthesis.getVoices();
        const indianVoice =
            voices.find(v => v.lang === 'en-IN') ||
            voices.find(v => v.lang.startsWith('en-IN')) ||
            voices.find(v => v.lang.startsWith('en-')) ||
            voices[0];

        if (indianVoice) {
            utterance.voice = indianVoice;
        }


        isSpeaking = true;

        utterance.onstart = () => {
            console.log('[VOICE] Speaking...');
        };

        utterance.onend = () => {
            isSpeaking = false;
            console.log('[VOICE] Finished speaking');
            resolve();
        };

        utterance.onerror = (error) => {
            isSpeaking = false;
            console.error('[VOICE] Speech error:', error);
            resolve(); // Don't reject, just continue
        };

        synthesis.speak(utterance);
    });
}

/**
 * Toggle voice input (start/stop listening)
 */
function toggleVoiceInput() {
    if (!voiceEnabled || !recognition) {
        showToast('Voice input not available in this browser. Use Chrome or Edge.', 'error');
        return;
    }

    if (isSpeaking) {
        // Stop speaking first
        synthesis.cancel();
        isSpeaking = false;
    }

    if (isListening) {
        // Stop listening
        recognition.stop();
    } else {
        // Start listening
        try {
            recognition.start();
        } catch (error) {
            console.error('[VOICE] Error starting recognition:', error);
            showToast('Could not start voice input', 'error');
        }
    }
}

/**
 * Update voice button appearance
 */
function updateVoiceButton(state) {
    const voiceBtn = document.getElementById('voice-input-btn');
    if (!voiceBtn) return;

    // Remove all state classes
    voiceBtn.classList.remove('listening', 'disabled');

    if (state === 'listening') {
        voiceBtn.classList.add('listening');
        voiceBtn.querySelector('.btn-icon').textContent = '⏹️';
        voiceBtn.title = 'Stop listening';
    } else if (state === 'ready') {
        voiceBtn.querySelector('.btn-icon').textContent = '🎙️';
        voiceBtn.title = 'Start voice input';
    } else if (state === 'disabled') {
        voiceBtn.classList.add('disabled');
        voiceBtn.querySelector('.btn-icon').textContent = '🎙️';
        voiceBtn.title = 'Voice not available';
    }
}

/**
 * Handle enter key in chat input
 */
function handleChatKeypress(event) {
    if (event.key === 'Enter') {
        sendMessage();
    }
}

/**
 * End session and show evaluation (REAL BACKEND)
 */
async function endSession() {
    // Stop timer
    if (chatTimer) {
        clearInterval(chatTimer);
        chatTimer = null;
    }

    // Stop any ongoing speech
    if (synthesis) {
        synthesis.cancel();
    }

    // Stop listening
    if (recognition && isListening) {
        recognition.stop();
    }

    // Store session duration
    window.sessionData.duration = chatSeconds;
    window.sessionData.messages = chatMessages;

    // Show loading
    showLoading('Generating AI evaluation...');

    // End session via REAL backend API
    try {
        const response = await endSessionAPI(window.sessionData.sessionId);
        
        if (response.success) {
            // Store evaluation in session data
            window.sessionData.evaluation = response.data.evaluation;
            
            console.log('[CHAT] Session ended with evaluation:', response.data.evaluation);
            
            hideLoading();
            
            // Navigate to evaluation screen
            goToScreen('evaluation');
            
            // Display the evaluation
            loadEvaluation();
        } else {
            throw new Error(response.error || 'Failed to end session');
        }
    } catch (error) {
        console.error('[CHAT] Error ending session:', error);
        hideLoading();
        showToast('Error getting evaluation: ' + error.message, 'error');
        
        // Fallback: show mock evaluation
        goToScreen('evaluation');
        displayMockEvaluation();
    }
}

/**
 * Load evaluation results from session data
 */
function loadEvaluation() {
    if (window.sessionData && window.sessionData.evaluation) {
        const formatted = formatEvaluationForUI(window.sessionData.evaluation);
        displayEvaluation(formatted);
        
        // Display full transcript
        displayFullTranscript(window.sessionData.messages);
    } else {
        console.error('[CHAT] No evaluation data available');
        displayMockEvaluation();
    }
}

/**
 * Display mock evaluation as fallback
 */
function displayMockEvaluation() {
    const mockEval = {
        overall: 0,
        details: {
            product: 0,
            communication: 0,
            objection: 0,
            engagement: 0
        },
        strengths: [
            "None",
            "None",
            "None"
        ],
        improvements: [
            "Continue the conversation longer for better evaluation",
            "Practice responding to more questions",
            "Engage in deeper discussion of policy details"
        ]
    };
    
    displayEvaluation(mockEval);
    displayFullTranscript(window.sessionData.messages || []);
}

/**
 * Display evaluation results
 */
function displayEvaluation(evaluation) {
    // Update overall score with animation
    const scoreElement = document.getElementById('overall-score');
    animateScore(scoreElement, 0, evaluation.overall, 1500);

    // Update detailed scores
    animateScore(document.getElementById('score-product'), 0, evaluation.details.product, 1200);
    animateScore(document.getElementById('score-communication'), 0, evaluation.details.communication, 1300);
    animateScore(document.getElementById('score-objection'), 0, evaluation.details.objection, 1400);
    animateScore(document.getElementById('score-engagement'), 0, evaluation.details.engagement, 1500);

    // Update strengths
    const strengthsList = document.getElementById('strengths-list');
    strengthsList.innerHTML = evaluation.strengths.map(item => `
        <li>
            <span class="feedback-icon strength">✓</span>
            <span>${item}</span>
        </li>
    `).join('');

    // Update improvements
    const improvementsList = document.getElementById('improvements-list');
    improvementsList.innerHTML = evaluation.improvements.map(item => `
        <li>
            <span class="feedback-icon improvement">!</span>
            <span>${item}</span>
        </li>
    `).join('');
}

/**
 * Display full transcript in evaluation
 */
function displayFullTranscript(messages) {
    const container = document.getElementById('full-transcript');
    
    if (!container) {
        console.warn('[CHAT] Transcript container not found');
        return;
    }
    
    if (!messages || messages.length === 0) {
        container.innerHTML = '<p style="color: var(--text-muted); text-align: center; padding: 2rem;">No conversation recorded</p>';
        return;
    }

    let html = '';
    messages.forEach((msg, index) => {
        const speaker = msg.role === 'user' ? 'SALESPERSON' : 'CUSTOMER';
        const speakerClass = msg.role === 'user' ? 'user' : 'ai';
        
        html += `
            <div class="transcript-entry">
                <div class="transcript-header">
                    <span class="speaker-label ${speakerClass}">${speaker}</span>
                    <span class="timestamp">${msg.time}</span>
                </div>
                <div class="message-text">${msg.content}</div>
            </div>
        `;
    });
    
    container.innerHTML = html;
}

/**
 * Download transcript
 */
function downloadTranscript() {
    const messages = window.sessionData.messages || chatMessages;
    
    if (!messages || messages.length === 0) {
        showToast('No transcript to download', 'error');
        return;
    }
    
    let text = `TRAINING SESSION TRANSCRIPT\n`;
    text += `=====================================\n\n`;
    text += `Persona: ${window.sessionData.persona.name}\n`;
    text += `Date: ${new Date().toLocaleString()}\n`;
    text += `Duration: ${formatDuration(window.sessionData.duration || chatSeconds)}\n`;
    text += `Messages: ${messages.length}\n\n`;
    text += `CONVERSATION:\n`;
    text += `=====================================\n\n`;
    
    messages.forEach(msg => {
        const speaker = msg.role === 'user' ? 'SALESPERSON' : 'CUSTOMER';
        text += `[${msg.time}] ${speaker}:\n${msg.content}\n\n`;
    });
    
    // Create download
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `transcript_${window.sessionData.sessionId}_${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    
    showToast('Transcript downloaded', 'success');
}

/**
 * Animate score counter
 */
function animateScore(element, start, end, duration) {
    const range = end - start;
    const startTime = performance.now();

    function update(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);

        // Easing function
        const easeOut = 1 - Math.pow(1 - progress, 3);
        const current = Math.round(start + range * easeOut);

        element.textContent = current;

        if (progress < 1) {
            requestAnimationFrame(update);
        }
    }

    requestAnimationFrame(update);
}

// Load voices when available
if (synthesis) {
    if (synthesis.onvoiceschanged !== undefined) {
        synthesis.onvoiceschanged = () => {
            console.log('[VOICE] Voices loaded:', synthesis.getVoices().length);
        };
    }
}