"""
Utility functions for PDF processing, audio handling, etc.
"""
import PyPDF2
import io
import wave
import numpy as np
from pathlib import Path
from typing import Optional
import logging

from config import POLICIES_DIR, SAMPLE_RATE

logger = logging.getLogger(__name__)


def extract_text_from_pdf(pdf_path: Path) -> Optional[str]:
    """
    Extract text content from a PDF file
    
    Args:
        pdf_path: Path to the PDF file
        
    Returns:
        Extracted text or None if extraction fails
    """
    try:
        with open(pdf_path, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            text_content = []
            
            for page_num in range(len(pdf_reader.pages)):
                page = pdf_reader.pages[page_num]
                text = page.extract_text()
                if text:
                    text_content.append(text)
            
            full_text = "\n\n".join(text_content)
            logger.info(f"Extracted {len(full_text)} characters from {pdf_path.name}")
            return full_text
            
    except Exception as e:
        logger.error(f"Failed to extract text from {pdf_path}: {e}")
        return None


def get_available_policies() -> list[str]:
    """
    Get list of available policy PDF files
    
    Returns:
        List of PDF filenames
    """
    try:
        pdf_files = [f.name for f in POLICIES_DIR.glob("*.pdf")]
        logger.info(f"Found {len(pdf_files)} policy files")
        return sorted(pdf_files)
    except Exception as e:
        logger.error(f"Failed to list policies: {e}")
        return []


def validate_policy_exists(policy_name: str) -> bool:
    """
    Check if a policy file exists
    
    Args:
        policy_name: Name of the policy PDF file
        
    Returns:
        True if file exists, False otherwise
    """
    policy_path = POLICIES_DIR / policy_name
    exists = policy_path.exists() and policy_path.is_file()
    
    if not exists:
        logger.warning(f"Policy not found: {policy_name}")
    
    return exists


def load_policy_content(policy_name: str) -> Optional[str]:
    """
    Load and extract content from a policy PDF
    
    Args:
        policy_name: Name of the policy PDF file
        
    Returns:
        Policy text content or None if loading fails
    """
    if not validate_policy_exists(policy_name):
        return None
    
    policy_path = POLICIES_DIR / policy_name
    return extract_text_from_pdf(policy_path)


def audio_bytes_to_numpy(audio_bytes: bytes, sample_rate: int = SAMPLE_RATE) -> np.ndarray:
    """
    Convert audio bytes (WAV format) to numpy array
    
    Args:
        audio_bytes: Raw audio data in WAV format
        sample_rate: Sample rate of the audio
        
    Returns:
        Numpy array of audio samples
    """
    try:
        audio_io = io.BytesIO(audio_bytes)
        with wave.open(audio_io, 'rb') as wav_file:
            frames = wav_file.readframes(wav_file.getnframes())
            audio_array = np.frombuffer(frames, dtype=np.int16)
            # Normalize to [-1, 1]
            audio_array = audio_array.astype(np.float32) / 32768.0
            return audio_array
    except Exception as e:
        logger.error(f"Failed to convert audio bytes to numpy: {e}")
        return np.array([])


def numpy_to_audio_bytes(audio_array: np.ndarray, sample_rate: int = SAMPLE_RATE) -> bytes:
    """
    Convert numpy array to audio bytes (WAV format)
    
    Args:
        audio_array: Numpy array of audio samples (float32, [-1, 1])
        sample_rate: Sample rate for the audio
        
    Returns:
        WAV format audio bytes
    """
    try:
        # Convert to int16
        audio_int16 = (audio_array * 32768.0).astype(np.int16)
        
        # Create WAV file in memory
        audio_io = io.BytesIO()
        with wave.open(audio_io, 'wb') as wav_file:
            wav_file.setnchannels(1)  # Mono
            wav_file.setsampwidth(2)  # 16-bit
            wav_file.setframerate(sample_rate)
            wav_file.writeframes(audio_int16.tobytes())
        
        return audio_io.getvalue()
    except Exception as e:
        logger.error(f"Failed to convert numpy to audio bytes: {e}")
        return b""


def format_duration(seconds: float) -> str:
    """
    Format duration in seconds to human-readable string
    
    Args:
        seconds: Duration in seconds
        
    Returns:
        Formatted string like "2m 30s"
    """
    minutes = int(seconds // 60)
    secs = int(seconds % 60)
    
    if minutes > 0:
        return f"{minutes}m {secs}s"
    return f"{secs}s"


def truncate_text(text: str, max_length: int = 100) -> str:
    """
    Truncate text to maximum length with ellipsis
    
    Args:
        text: Text to truncate
        max_length: Maximum length
        
    Returns:
        Truncated text
    """
    if len(text) <= max_length:
        return text
    return text[:max_length-3] + "..."


def get_policy_display_name(filename: str) -> str:
    """
    Convert PDF filename to display name
    
    Args:
        filename: PDF filename (e.g., "term_life_insurance.pdf")
        
    Returns:
        Display name (e.g., "Term Life Insurance")
    """
    # Remove .pdf extension
    name = filename.replace('.pdf', '')
    # Replace underscores with spaces
    name = name.replace('_', ' ')
    # Capitalize each word
    name = ' '.join(word.capitalize() for word in name.split())
    return name