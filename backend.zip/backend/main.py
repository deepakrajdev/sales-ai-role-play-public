"""
FastAPI application for Voice-First AI Policy Training System
FIXED VERSION - Added REST chat endpoint for frontend integration
"""
import uuid
import logging
from typing import Dict, List
from contextlib import asynccontextmanager

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from models import (
    SessionStartRequest, SessionStatus, SessionEvaluation,
    PolicyInfo, ErrorResponse, DEFAULT_PERSONAS, PersonalityTraits,
    ConversationTurn
)
from config import CORS_ORIGINS, LOG_LEVEL, LOG_FORMAT
from database import db
from voice_bot import VoiceBot
from evaluator import evaluator
from utils import get_available_policies, validate_policy_exists, get_policy_display_name
from prompts import build_practice_mode_prompt
from llm_provider import create_llm_provider
from datetime import datetime

# Configure logging
logging.basicConfig(level=LOG_LEVEL, format=LOG_FORMAT)
logger = logging.getLogger(__name__)

# Active voice bot sessions (in-memory during calls)
active_sessions: Dict[str, VoiceBot] = {}

# Active LLM sessions for chat (in-memory)
active_llm_sessions: Dict[str, Dict] = {}


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager"""
    # Startup
    logger.info("Starting Voice-First AI Policy Training System")
    await evaluator.initialize()
    yield
    # Shutdown
    logger.info("Shutting down application")
    # Clean up active sessions
    for voice_bot in active_sessions.values():
        await voice_bot.cleanup()
    await evaluator.cleanup()


# Initialize FastAPI app
app = FastAPI(
    title="Voice-First AI Policy Training API",
    description="Backend API for insurance sales training with AI personas",
    version="1.0.0",
    lifespan=lifespan
)

# Add CORS middleware - FIXED: Added more origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://localhost:5173",
        "http://localhost:8080",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:5173", 
        "http://127.0.0.1:8080",
        "http://127.0.0.1:5500",  # VSCode Live Server
        "http://localhost:5500",   # VSCode Live Server
        "*"  # Allow all for development - REMOVE IN PRODUCTION
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ==================== REST API Endpoints ====================

@app.get("/")
async def root():
    """API health check"""
    return {
        "status": "online",
        "service": "Voice-First AI Policy Training",
        "version": "1.0.0"
    }


@app.get("/api/policies", response_model=List[PolicyInfo])
async def list_policies():
    """
    Get list of available insurance policies
    
    Returns:
        List of PolicyInfo objects
    """
    try:
        policy_files = get_available_policies()
        
        policies = [
            PolicyInfo(
                filename=filename,
                display_name=get_policy_display_name(filename)
            )
            for filename in policy_files
        ]
        
        logger.info(f"Returning {len(policies)} available policies")
        return policies
        
    except Exception as e:
        logger.error(f"Failed to list policies: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve policy list"
        )


@app.get("/api/personas")
async def list_personas():
    """
    Get list of available personas with their default traits
    
    Returns:
        Dictionary of persona configurations
    """
    personas_data = {
        persona.value: {
            "display_name": persona.value.replace('_', ' ').title(),
            "default_traits": traits.model_dump()
        }
        for persona, traits in DEFAULT_PERSONAS.items()
    }
    
    return personas_data


@app.post("/api/sessions/start", response_model=SessionStatus)
async def start_session(request: SessionStartRequest):
    """
    Start a new training session
    
    Args:
        request: SessionStartRequest with mode, policy, persona, and optional traits
        
    Returns:
        SessionStatus with session_id
    """
    try:
        # Validate policy exists
        if not validate_policy_exists(request.policy):
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"No such policy exists: {request.policy}"
            )
        
        # Use default traits if not provided
        traits = request.traits or DEFAULT_PERSONAS[request.persona]
        
        # Generate unique session ID
        session_id = str(uuid.uuid4())
        
        # Create session in database
        success = db.create_session(
            session_id=session_id,
            mode=request.mode,
            policy=request.policy,
            persona=request.persona,
            traits=traits
        )
        
        if not success:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to create session"
            )
        
        # Initialize LLM session for chat
        from utils import load_policy_content
        policy_content = load_policy_content(request.policy)
        
        active_llm_sessions[session_id] = {
            "llm_provider": create_llm_provider("google"),  # Tries Google first, falls back to Ollama
            "persona": request.persona,
            "traits": traits,  # These are the custom traits from frontend
            "policy_content": policy_content,
            "conversation_history": [],
            "turn_count": 0,
            "mode": request.mode
        }
        
        logger.info(f"Session {session_id} initialized with custom traits: {traits.model_dump()}")
        
        # Retrieve created session
        session = db.get_session(session_id)
        
        logger.info(f"Created session {session_id}: {request.mode.value}, {request.persona.value}")
        return session
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to start session: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


# NEW ENDPOINT: Chat message for REST API
class ChatMessageRequest(BaseModel):
    message: str
    session_id: str


class ChatMessageResponse(BaseModel):
    message: str
    timestamp: str


@app.post("/api/chat/message", response_model=ChatMessageResponse)
async def send_chat_message(request: ChatMessageRequest):
    """
    Send a chat message and get AI response (REST API endpoint)
    
    Args:
        request: ChatMessageRequest with message and session_id
        
    Returns:
        ChatMessageResponse with AI's reply
    """
    try:
        session_id = request.session_id
        user_message = request.message
        
        # Check if session exists
        if session_id not in active_llm_sessions:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Session not found or expired: {session_id}"
            )
        
        session_data = active_llm_sessions[session_id]
        llm_provider = session_data["llm_provider"]
        
        # Build system prompt
        system_prompt = build_practice_mode_prompt(
            persona=session_data["persona"],
            traits=session_data["traits"],
            policy_content=session_data["policy_content"],
            turn_count=session_data["turn_count"]
        )
        
        # Add user message to history
        session_data["conversation_history"].append({
            "role": "user",
            "content": user_message
        })
        
        # Generate AI response
        ai_response = await llm_provider.generate_response(
            system_prompt=system_prompt,
            conversation_history=session_data["conversation_history"],
            max_tokens=150 if session_data["traits"].verbosity <= 5 else 250,
            temperature=0.8
        )
        
        if not ai_response:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to generate AI response"
            )
        
        # Add AI response to history
        session_data["conversation_history"].append({
            "role": "assistant",
            "content": ai_response
        })
        
        session_data["turn_count"] += 1
        
        # Save conversation turns to database
        db.add_conversation_turn(
            session_id=session_id,
            turn=ConversationTurn(
                turn_id=session_data["turn_count"] * 2 - 1,
                timestamp=datetime.now(),
                speaker="user",
                text=user_message
            )
        )
        
        db.add_conversation_turn(
            session_id=session_id,
            turn=ConversationTurn(
                turn_id=session_data["turn_count"] * 2,
                timestamp=datetime.now(),
                speaker="ai",
                text=ai_response
            )
        )
        
        logger.info(f"Chat message processed for session {session_id}")
        
        return ChatMessageResponse(
            message=ai_response,
            timestamp=datetime.now().isoformat()
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error processing chat message: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@app.get("/api/sessions/{session_id}/status", response_model=SessionStatus)
async def get_session_status(session_id: str):
    """
    Get current status and transcript of a session
    
    Args:
        session_id: Session UUID
        
    Returns:
        SessionStatus with full transcript
    """
    session = db.get_session(session_id)
    
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session not found: {session_id}"
        )
    
    return session


@app.post("/api/sessions/{session_id}/end", response_model=SessionEvaluation)
async def end_session(session_id: str):
    """
    End a training session and generate evaluation
    
    Args:
        session_id: Session UUID
        
    Returns:
        SessionEvaluation with scores and feedback
    """
    try:
        # Check if session exists
        session = db.get_session(session_id)
        if not session:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Session not found: {session_id}"
            )
        
        # Mark session as ended
        db.end_session(session_id)
        
        # Clean up active voice bot if exists
        if session_id in active_sessions:
            await active_sessions[session_id].cleanup()
            del active_sessions[session_id]
        
        # Clean up active LLM session if exists
        if session_id in active_llm_sessions:
            llm_session = active_llm_sessions[session_id]
            if hasattr(llm_session["llm_provider"], 'close'):
                await llm_session["llm_provider"].close()
            del active_llm_sessions[session_id]
        
        # Generate evaluation
        logger.info(f"Generating evaluation for session: {session_id}")
        
        # Initialize evaluator if not already done
        if not hasattr(evaluator, 'llm_provider') or evaluator.llm_provider is None:
            await evaluator.initialize()
        
        evaluation = await evaluator.evaluate_session(session_id)
        
        if not evaluation:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to generate evaluation"
            )
        
        logger.info(f"Session {session_id} ended with overall score: {evaluation.scores.overall}")
        return evaluation
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to end session: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@app.get("/api/sessions/{session_id}/evaluation", response_model=SessionEvaluation)
async def get_evaluation(session_id: str):
    """
    Retrieve evaluation for a completed session
    
    Args:
        session_id: Session UUID
        
    Returns:
        SessionEvaluation if available
    """
    evaluation = db.get_evaluation(session_id)
    
    if not evaluation:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No evaluation found for session: {session_id}"
        )
    
    return evaluation


# ==================== WebSocket Voice Streaming ====================

@app.websocket("/ws/voice/{session_id}")
async def voice_websocket(websocket: WebSocket, session_id: str):
    """
    WebSocket endpoint for real-time voice streaming
    
    Protocol:
    - Client sends: audio chunks (binary WAV data)
    - Server sends: audio responses (binary WAV data)
    """
    await websocket.accept()
    logger.info(f"WebSocket connected for session: {session_id}")
    
    voice_bot = None
    
    try:
        # Validate session exists
        session = db.get_session(session_id)
        if not session:
            await websocket.send_json({
                "error": "Session not found",
                "session_id": session_id
            })
            await websocket.close()
            return
        
        # Initialize voice bot
        voice_bot = VoiceBot(session_id)
        if not await voice_bot.initialize():
            await websocket.send_json({
                "error": "Failed to initialize voice bot"
            })
            await websocket.close()
            return
        
        # Store in active sessions
        active_sessions[session_id] = voice_bot
        
        # Send initial greeting
        greeting_audio = await voice_bot.get_ai_greeting()
        if greeting_audio:
            await websocket.send_bytes(greeting_audio)
            logger.info("Sent AI greeting")
        
        # Main voice interaction loop
        while True:
            # Receive audio chunk from client
            audio_data = await websocket.receive_bytes()
            
            if not audio_data:
                logger.warning("Received empty audio data")
                continue
            
            # Process audio through pipeline
            response_audio = await voice_bot.process_audio_chunk(audio_data)
            
            if response_audio:
                # Send AI response back to client
                await websocket.send_bytes(response_audio)
            else:
                logger.warning("No response generated for audio chunk")
    
    except WebSocketDisconnect:
        logger.info(f"WebSocket disconnected for session: {session_id}")
    
    except Exception as e:
        logger.error(f"WebSocket error for session {session_id}: {e}")
        try:
            await websocket.send_json({
                "error": str(e)
            })
        except:
            pass
    
    finally:
        # Cleanup
        if voice_bot:
            await voice_bot.cleanup()
        
        if session_id in active_sessions:
            del active_sessions[session_id]
        
        try:
            await websocket.close()
        except:
            pass
        
        logger.info(f"WebSocket cleaned up for session: {session_id}")


# ==================== Error Handlers ====================

@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc):
    """Handle HTTP exceptions"""
    return JSONResponse(
        status_code=exc.status_code,
        content=ErrorResponse(
            error=exc.detail,
            detail=str(exc)
        ).model_dump()
    )


@app.exception_handler(Exception)
async def general_exception_handler(request, exc):
    """Handle unexpected exceptions"""
    logger.error(f"Unhandled exception: {exc}")
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content=ErrorResponse(
            error="Internal server error",
            detail=str(exc)
        ).model_dump()
    )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )