"""
Configuration settings for the Voice-First AI Policy Training System
"""
import os
from pathlib import Path

# Base directories
BASE_DIR = Path(__file__).parent
POLICIES_DIR = BASE_DIR / "Policies"
TRANSCRIPTS_DIR = BASE_DIR / "transcripts"
DATABASE_PATH = BASE_DIR / "sessions.db"

# Create directories if they don't exist
POLICIES_DIR.mkdir(exist_ok=True)
TRANSCRIPTS_DIR.mkdir(exist_ok=True)

# Google Generative AI Configuration (Primary)
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY", "AIzaSyBSO_6etAMaVBALwnGelnLtuRi-wVkmKmA")
GOOGLE_MODEL = os.getenv("GOOGLE_MODEL", "gemini-2.5-flash-lite")

# Ollama Configuration (Fallback)
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "gpt-oss:120b-cloud")
OLLAMA_API_KEY = os.getenv("OLLAMA_API_KEY", "")  # If using Ollama Cloud

# Piper TTS Configuration
PIPER_MODEL_PATH = os.getenv("PIPER_MODEL_PATH", "./piper_models/en_US-lessac-medium.onnx")
PIPER_EXECUTABLE = os.getenv("PIPER_EXECUTABLE", r"piper\piper.exe")  # Path to piper binary

# Audio Configuration
SAMPLE_RATE = 16000  # Audio sampling rate
CHUNK_SIZE = 8000  # Audio chunk size in bytes
AUDIO_FORMAT = "wav"

# Session Configuration
MAX_SESSION_DURATION = 3600  # 1 hour max
MAX_TURNS_PER_SESSION = 100

# Evaluation Configuration
EVALUATION_MODEL = OLLAMA_MODEL  # Can be different model for evaluation

# Logging
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

# CORS (for frontend)
CORS_ORIGINS = [
    "http://localhost:3000",
    "http://localhost:5173",
    "http://localhost:8080"
]