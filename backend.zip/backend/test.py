"""
System verification script to test all components
Run this after installation to ensure everything is configured correctly
"""
import asyncio
import sys
from pathlib import Path

def check_imports():
    """Check if all required packages are installed"""
    print("🔍 Checking Python dependencies...")
    
    required_packages = [
        ('fastapi', 'FastAPI'),
        ('uvicorn', 'Uvicorn'),
        ('pydantic', 'Pydantic'),
        ('httpx', 'HTTPX'),
        ('faster_whisper', 'Faster Whisper'),
        ('numpy', 'NumPy'),
        ('PyPDF2', 'PyPDF2'),
    ]
    
    missing = []
    for module, name in required_packages:
        try:
            __import__(module)
            print(f"  ✅ {name}")
        except ImportError:
            print(f"  ❌ {name} - NOT INSTALLED")
            missing.append(name)
    
    if missing:
        print(f"\n⚠️  Missing packages: {', '.join(missing)}")
        print("Run: pip install -r requirements.txt")
        return False
    
    print("✅ All Python dependencies installed\n")
    return True


def check_directories():
    """Check if required directories exist"""
    print("📁 Checking directory structure...")
    
    required_dirs = [
        ('Policies', 'Policy PDFs storage'),
        ('transcripts', 'Session transcripts (auto-created)'),
    ]
    
    for dir_name, description in required_dirs:
        dir_path = Path(dir_name)
        if dir_path.exists():
            print(f"  ✅ {dir_name}/ - {description}")
        else:
            print(f"  ⚠️  {dir_name}/ - Creating...")
            dir_path.mkdir(exist_ok=True)
    
    print("✅ Directory structure ready\n")
    return True


def check_policies():
    """Check if policy PDFs are available"""
    print("📄 Checking policy files...")
    
    policies_dir = Path('Policies')
    pdf_files = list(policies_dir.glob('*.pdf'))
    
    if pdf_files:
        print(f"  ✅ Found {len(pdf_files)} policy PDF(s):")
        for pdf in pdf_files:
            print(f"     - {pdf.name}")
    else:
        print("  ⚠️  No policy PDFs found in Policies/ directory")
        print("     Add your insurance policy PDF files to Policies/")
        return False
    
    print("✅ Policy files available\n")
    return True


def check_env_file():
    """Check if .env file exists"""
    print("⚙️  Checking configuration...")
    
    env_path = Path('.env')
    if env_path.exists():
        print("  ✅ .env file found")
        
        # Read and validate key variables
        with open(env_path) as f:
            content = f.read()
            
            required_vars = ['OLLAMA_BASE_URL', 'OLLAMA_MODEL', 'PIPER_EXECUTABLE']
            for var in required_vars:
                if var in content:
                    print(f"  ✅ {var} configured")
                else:
                    print(f"  ⚠️  {var} not found in .env")
    else:
        print("  ⚠️  .env file not found")
        print("     Copy .env.example to .env and configure")
        return False
    
    print("✅ Configuration file ready\n")
    return True


def check_piper():
    """Check if Piper TTS is available"""
    print("🔊 Checking Piper TTS...")
    
    import subprocess
    import os
    from pathlib import Path
    
    try:
        # Get piper executable from config
        from config import PIPER_EXECUTABLE
        
        # Handle None or empty string
        if not PIPER_EXECUTABLE:
            print("  ⚠️  PIPER_EXECUTABLE not configured in .env")
            print("     Set PIPER_EXECUTABLE=path/to/piper.exe in .env")
            return False
        
        # Convert to Path object
        piper_path = Path(PIPER_EXECUTABLE)
        
        # Check if file exists
        if not piper_path.exists():
            print(f"  ⚠️  Piper executable not found at: {piper_path}")
            print("     Download from: https://github.com/rhasspy/piper/releases")
            return False
        
        # Try to run piper --version
        result = subprocess.run(
            [str(piper_path), '--version'],
            capture_output=True,
            text=True,
            timeout=5
        )
        
        if result.returncode == 0:
            print(f"  ✅ Piper TTS installed at {piper_path}")
        else:
            print(f"  ⚠️  Piper TTS found but may not be working correctly")
            
    except ImportError:
        print("  ⚠️  Cannot import config.py - make sure all backend files are present")
        return False
    except FileNotFoundError:
        print("  ❌ Piper TTS not found")
        print("     Install from: https://github.com/rhasspy/piper")
        return False
    except Exception as e:
        print(f"  ⚠️  Error checking Piper: {e}")
        return False
    
    # Check for voice model
    model_path = Path('piper_models/en_US-lessac-medium.onnx')
    if model_path.exists():
        print(f"  ✅ Voice model found: {model_path}")
    else:
        print(f"  ⚠️  Voice model not found at {model_path}")
        print("     Download from: https://huggingface.co/rhasspy/piper-voices")
        return False
    
    print("✅ Piper TTS ready\n")
    return True


async def check_ollama():
    """Check if Ollama is accessible"""
    print("🤖 Checking Ollama connection...")
    
    import httpx
    from config import OLLAMA_BASE_URL
    
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(f"{OLLAMA_BASE_URL}/api/tags")
            if response.status_code == 200:
                print(f"  ✅ Ollama accessible at {OLLAMA_BASE_URL}")
                return True
            else:
                print(f"  ⚠️  Ollama returned status {response.status_code}")
                return False
    except Exception as e:
        print(f"  ❌ Cannot connect to Ollama: {e}")
        print("     Check OLLAMA_BASE_URL in .env")
        return False


def check_database():
    """Check database initialization"""
    print("💾 Checking database...")
    
    try:
        # Check if database.py exists
        from pathlib import Path
        if not Path('database.py').exists():
            print("  ❌ database.py file not found")
            print("     Make sure all backend files are in the project folder")
            return False
        
        from database import db
        
        # Try to initialize database
        db.init_database()
        print("  ✅ Database initialized successfully")
        
        # Check if database file exists
        from config import DATABASE_PATH
        if Path(DATABASE_PATH).exists():
            print(f"  ✅ Database file: {DATABASE_PATH}")
        
        print("✅ Database ready\n")
        return True
    except ImportError as e:
        print(f"  ❌ Cannot import database module: {e}")
        print("     Make sure database.py is in the project folder")
        return False
    except Exception as e:
        print(f"  ❌ Database error: {e}")
        return False


async def run_all_checks():
    """Run all verification checks"""
    print("=" * 60)
    print("🚀 Voice-First AI Training System - Setup Verification")
    print("=" * 60)
    print()
    
    checks = [
        ("Dependencies", check_imports()),
        ("Directories", check_directories()),
        ("Configuration", check_env_file()),
        ("Policy Files", check_policies()),
        ("Database", check_database()),
        ("Piper TTS", check_piper()),
    ]
    
    # Async check for Ollama
    ollama_ok = await check_ollama()
    checks.append(("Ollama Connection", ollama_ok))
    
    print("=" * 60)
    print("📊 VERIFICATION SUMMARY")
    print("=" * 60)
    
    all_passed = True
    for name, status in checks:
        icon = "✅" if status else "❌"
        print(f"{icon} {name}")
        if not status:
            all_passed = False
    
    print("=" * 60)
    
    if all_passed:
        print("🎉 All checks passed! System is ready to run.")
        print("\nStart the server with:")
        print("  python main.py")
        print("\nAPI docs will be available at:")
        print("  http://localhost:8000/docs")
        return 0
    else:
        print("⚠️  Some checks failed. Please fix the issues above.")
        return 1


if __name__ == "__main__":
    exit_code = asyncio.run(run_all_checks())
    sys.exit(exit_code)