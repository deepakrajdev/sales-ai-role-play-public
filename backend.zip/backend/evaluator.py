"""
Post-session evaluation engine for analyzing performance
"""
import json
import logging
from datetime import datetime
from typing import Optional, Any, Dict

from models import SessionEvaluation, EvaluationScores, EvaluationFeedback
from llm_provider import create_llm_provider, LLMProvider
from prompts import build_evaluation_prompt, format_transcript_for_evaluation
from database import db

logger = logging.getLogger(__name__)


class SessionEvaluator:
    """
    Evaluates training session performance and generates structured feedback
    """
    
    def __init__(self):
        self.llm_provider: Optional[LLMProvider] = None
    
    async def initialize(self):
        """Initialize LLM provider for evaluation - use Ollama by default, Google as fallback"""
        try:
            # Try Ollama first (default provider)
            self.llm_provider = create_llm_provider("ollama")
            logger.info("SessionEvaluator initialized with Ollama provider")
            return True
        except Exception as e:
            logger.warning(f"Ollama initialization failed: {e}. Attempting Google API...")
            try:
                # Fallback to Google
                self.llm_provider = create_llm_provider("google")
                logger.info("SessionEvaluator initialized with Google Generative AI provider")
                return True
            except Exception as e2:
                logger.error(f"Both Ollama and Google initialization failed: {e2}")
                return False
    
    async def evaluate_session(self, session_id: str) -> Optional[SessionEvaluation]:
        """
        Evaluate a completed training session
        
        Args:
            session_id: ID of the session to evaluate
            
        Returns:
            SessionEvaluation object or None if evaluation fails
        """
        try:
            # Retrieve session from database
            session = db.get_session(session_id)
            if not session:
                logger.error(f"Session not found: {session_id}")
                return None
            
            if len(session.transcript) < 2:
                logger.warning(f"Session {session_id} has insufficient conversation data")
                evaluation = self._create_minimal_evaluation(session_id, session)
                
                # Save minimal evaluation to database
                save_success = db.save_evaluation(evaluation)
                if not save_success:
                    logger.error(f"Failed to save minimal evaluation to database for {session_id}")
                else:
                    logger.info(f"Minimal evaluation saved to database for {session_id}")
                
                return evaluation
            
            # Format transcript for evaluation
            transcript_text = format_transcript_for_evaluation(session.transcript)
            
            # Build evaluation prompt
            evaluation_prompt = build_evaluation_prompt()
            
            # Generate evaluation using LLM
            logger.info(f"Generating evaluation for session: {session_id}")
            evaluation_json = await self.llm_provider.generate_evaluation(
                evaluation_prompt=evaluation_prompt,
                transcript=transcript_text
            )
            
            if not evaluation_json:
                logger.error("Failed to generate evaluation from LLM")
                return None
            
            # Parse JSON response
            evaluation_data = self._parse_evaluation_json(evaluation_json)
            if not evaluation_data:
                logger.error("Failed to parse evaluation JSON")
                return None
            
            # Calculate session metrics
            duration = self._calculate_session_duration(session)
            
            # Create evaluation object
            evaluation = SessionEvaluation(
                session_id=session_id,
                scores=EvaluationScores(**evaluation_data['scores']),
                feedback=EvaluationFeedback(**evaluation_data['feedback']),
                total_duration=duration,
                total_turns=len(session.transcript),
                evaluated_at=datetime.now()
            )
            
            # Save to database
            save_success = db.save_evaluation(evaluation)
            
            if not save_success:
                logger.error(f"Failed to save evaluation to database for session {session_id}")
                # Still return the evaluation even if save failed
            else:
                logger.info(f"Evaluation saved to database for session {session_id}")
            
            logger.info(f"Evaluation completed for session: {session_id}")
            return evaluation
            
        except Exception as e:
            logger.error(f"Evaluation failed for session {session_id}: {e}")
            return None
    
    def _parse_evaluation_json(self, json_string: str) -> Optional[Dict[str, Any]]:
        """
        Parse and validate evaluation JSON
        
        Args:
            json_string: JSON string from LLM
            
        Returns:
            Parsed dictionary or None if invalid
        """
        try:
            # Clean up potential markdown code blocks
            cleaned = json_string.strip()
            if cleaned.startswith('```'):
                # Remove code block markers
                lines = cleaned.split('\n')
                cleaned = '\n'.join(lines[1:-1]) if len(lines) > 2 else cleaned
            
            # Parse JSON
            data = json.loads(cleaned)
            
            # Validate structure
            if 'scores' not in data or 'feedback' not in data:
                logger.error("Evaluation JSON missing required fields")
                return None
            
            # Validate scores
            required_scores = [
                'overall', 'product_explanation', 'communication_skills',
                'objection_handling', 'engagement'
            ]
            for score_key in required_scores:
                if score_key not in data['scores']:
                    logger.error(f"Missing score: {score_key}")
                    return None
                
                # Ensure scores are in valid range
                score_value = data['scores'][score_key]
                if not isinstance(score_value, int) or score_value < 1 or score_value > 100:
                    logger.warning(f"Invalid score value for {score_key}: {score_value}")
                    data['scores'][score_key] = max(1, min(100, int(score_value)))
            
            # Validate feedback
            if 'key_strengths' not in data['feedback']:
                data['feedback']['key_strengths'] = ["Participated in the session"]
            if 'areas_of_improvement' not in data['feedback']:
                data['feedback']['areas_of_improvement'] = ["Continue practicing"]
            
            # Ensure lists have 3-4 items
            data['feedback']['key_strengths'] = data['feedback']['key_strengths'][:4]
            data['feedback']['areas_of_improvement'] = data['feedback']['areas_of_improvement'][:4]
            
            while len(data['feedback']['key_strengths']) < 3:
                data['feedback']['key_strengths'].append("Engaged in the conversation")
            
            while len(data['feedback']['areas_of_improvement']) < 3:
                data['feedback']['areas_of_improvement'].append("Continue practicing regularly")
            
            return data
            
        except json.JSONDecodeError as e:
            logger.error(f"JSON parsing failed: {e}")
            logger.debug(f"Raw JSON: {json_string}")
            return None
        except Exception as e:
            logger.error(f"Evaluation parsing error: {e}")
            return None
    
    def _calculate_session_duration(self, session: Any) -> float:
        """
        Calculate total session duration in seconds
        
        Args:
            session: SessionStatus object
            
        Returns:
            Duration in seconds
        """
        if not session.ended_at or not session.started_at:
            return 0.0
        
        duration = (session.ended_at - session.started_at).total_seconds()
        return max(0.0, duration)
    
    def _create_minimal_evaluation(self, session_id: str, session: Any) -> SessionEvaluation:
        """
        Create a minimal evaluation for sessions with insufficient data
        
        Args:
            session_id: Session ID
            session: SessionStatus object
            
        Returns:
            Minimal SessionEvaluation
        """
        logger.info(f"Creating minimal evaluation for session: {session_id}")
        
        duration = self._calculate_session_duration(session)
        
        return SessionEvaluation(
            session_id=session_id,
            scores=EvaluationScores(
                overall=50,
                product_explanation=50,
                communication_skills=50,
                objection_handling=50,
                engagement=50
            ),
            feedback=EvaluationFeedback(
                key_strengths=[
                    "Initiated the training session",
                    "Showed willingness to learn",
                    "Engaged with the AI assistant"
                ],
                areas_of_improvement=[
                    "Continue the conversation longer for better evaluation",
                    "Practice responding to more questions",
                    "Engage in deeper discussion of policy details"
                ]
            ),
            total_duration=duration,
            total_turns=len(session.transcript),
            evaluated_at=datetime.now()
        )
    
    async def cleanup(self):
        """Clean up resources"""
        if self.llm_provider and hasattr(self.llm_provider, 'close'):
            await self.llm_provider.close()
        logger.info("SessionEvaluator cleaned up")


# Global evaluator instance
evaluator = SessionEvaluator()