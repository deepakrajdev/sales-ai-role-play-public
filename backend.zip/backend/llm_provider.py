"""
Abstract LLM provider interface with implementations for Ollama, Google Generative AI, OpenAI, Azure
This allows easy switching between LLM backends with fallback support
"""
from abc import ABC, abstractmethod
from typing import List, Dict, Optional
import httpx
import logging
import json

from config import OLLAMA_BASE_URL, OLLAMA_MODEL, OLLAMA_API_KEY, GOOGLE_API_KEY, GOOGLE_MODEL

logger = logging.getLogger(__name__)


class LLMProvider(ABC):
    """Abstract base class for LLM providers"""
    
    @abstractmethod
    async def generate_response(
        self,
        system_prompt: str,
        conversation_history: List[Dict[str, str]],
        max_tokens: int = 150,
        temperature: float = 0.7
    ) -> Optional[str]:
        """
        Generate a response from the LLM
        
        Args:
            system_prompt: System prompt defining AI behavior
            conversation_history: List of {"role": "user/assistant", "content": "..."}
            max_tokens: Maximum tokens in response
            temperature: Sampling temperature
            
        Returns:
            Generated text response or None if failed
        """
        pass
    
    @abstractmethod
    async def generate_evaluation(
        self,
        evaluation_prompt: str,
        transcript: str
    ) -> Optional[str]:
        """
        Generate structured evaluation JSON
        
        Args:
            evaluation_prompt: Prompt for evaluation
            transcript: Full conversation transcript
            
        Returns:
            JSON string with evaluation or None if failed
        """
        pass


class OllamaProvider(LLMProvider):
    """Ollama Cloud/Local implementation"""
    
    def __init__(
        self,
        base_url: str = OLLAMA_BASE_URL,
        model: str = OLLAMA_MODEL,
        api_key: str = OLLAMA_API_KEY
    ):
        self.base_url = base_url.rstrip('/')
        self.model = model
        self.api_key = api_key
        self.client = httpx.AsyncClient(timeout=30.0)
    
    async def generate_response(
        self,
        system_prompt: str,
        conversation_history: List[Dict[str, str]],
        max_tokens: int = 150,
        temperature: float = 0.7
    ) -> Optional[str]:
        """Generate response using Ollama API"""
        try:
            # Build messages array
            messages = [{"role": "system", "content": system_prompt}]
            messages.extend(conversation_history)
            
            # Prepare request
            headers = {}
            if self.api_key:
                headers["Authorization"] = f"Bearer {self.api_key}"
            
            payload = {
                "model": self.model,
                "messages": messages,
                "options": {
                    "num_predict": max_tokens,
                    "temperature": temperature,
                },
                "stream": False
            }
            
            # Make request
            response = await self.client.post(
                f"{self.base_url}/api/chat",
                json=payload,
                headers=headers
            )
            
            if response.status_code != 200:
                logger.error(f"Ollama API error: {response.status_code} - {response.text}")
                return None
            
            result = response.json()
            generated_text = result.get("message", {}).get("content", "")
            
            logger.debug(f"Generated response: {generated_text[:100]}...")
            return generated_text
            
        except Exception as e:
            logger.error(f"Ollama generation failed: {e}")
            return None
    
    async def generate_evaluation(
        self,
        evaluation_prompt: str,
        transcript: str
    ) -> Optional[str]:
        """Generate evaluation using Ollama"""
        try:
            # Build evaluation message
            full_prompt = f"{evaluation_prompt}\n\nTRANSCRIPT:\n{transcript}"
            
            messages = [
                {"role": "user", "content": full_prompt}
            ]
            
            headers = {}
            if self.api_key:
                headers["Authorization"] = f"Bearer {self.api_key}"
            
            payload = {
                "model": self.model,
                "messages": messages,
                "options": {
                    "num_predict": 1000,
                    "temperature": 0.3,  # Lower temperature for structured output
                },
                "stream": False,
                "format": "json"  # Request JSON format
            }
            
            response = await self.client.post(
                f"{self.base_url}/api/chat",
                json=payload,
                headers=headers
            )
            
            if response.status_code != 200:
                logger.error(f"Ollama evaluation error: {response.status_code}")
                return None
            
            result = response.json()
            evaluation_json = result.get("message", {}).get("content", "")
            
            logger.info(f"Generated evaluation (length: {len(evaluation_json)})")
            return evaluation_json
            
        except Exception as e:
            logger.error(f"Ollama evaluation failed: {e}")
            return None
    
    async def close(self):
        """Close HTTP client"""
        await self.client.aclose()


class OpenAIProvider(LLMProvider):
    """OpenAI API implementation (future use)"""
    
    def __init__(self, api_key: str, model: str = "gpt-4"):
        self.api_key = api_key
        self.model = model
        # Initialize OpenAI client here
        logger.info("OpenAI provider initialized (placeholder)")
    
    async def generate_response(
        self,
        system_prompt: str,
        conversation_history: List[Dict[str, str]],
        max_tokens: int = 150,
        temperature: float = 0.7
    ) -> Optional[str]:
        """Generate response using OpenAI API"""
        # TODO: Implement OpenAI API call
        # from openai import AsyncOpenAI
        # client = AsyncOpenAI(api_key=self.api_key)
        # response = await client.chat.completions.create(...)
        raise NotImplementedError("OpenAI provider not yet implemented")
    
    async def generate_evaluation(
        self,
        evaluation_prompt: str,
        transcript: str
    ) -> Optional[str]:
        """Generate evaluation using OpenAI"""
        raise NotImplementedError("OpenAI provider not yet implemented")


class AzureOpenAIProvider(LLMProvider):
    """Azure OpenAI implementation (future use)"""
    
    def __init__(self, endpoint: str, api_key: str, deployment: str):
        self.endpoint = endpoint
        self.api_key = api_key
        self.deployment = deployment
        logger.info("Azure OpenAI provider initialized (placeholder)")
    
    async def generate_response(
        self,
        system_prompt: str,
        conversation_history: List[Dict[str, str]],
        max_tokens: int = 150,
        temperature: float = 0.7
    ) -> Optional[str]:
        """Generate response using Azure OpenAI"""
        raise NotImplementedError("Azure OpenAI provider not yet implemented")
    
    async def generate_evaluation(
        self,
        evaluation_prompt: str,
        transcript: str
    ) -> Optional[str]:
        """Generate evaluation using Azure OpenAI"""
        raise NotImplementedError("Azure OpenAI provider not yet implemented")


class GoogleGenerativeAIProvider(LLMProvider):
    """Google Generative AI (Gemini) implementation using google.genai"""
    
    def __init__(self, api_key: str = GOOGLE_API_KEY, model: str = GOOGLE_MODEL):
        if not api_key:
            raise ValueError("GOOGLE_API_KEY is required for Google Generative AI provider")
        
        try:
            import google.genai as genai
            self.genai = genai
            self.client = genai.Client(api_key=api_key)
            self.model = model
            logger.info(f"Google Generative AI provider initialized with model: {model}")
        except ImportError:
            raise ImportError("google-genai package not installed. Install with: pip install google-genai")
    
    async def generate_response(
        self,
        system_prompt: str,
        conversation_history: List[Dict[str, str]],
        max_tokens: int = 150,
        temperature: float = 0.7
    ) -> Optional[str]:
        """Generate response using Google Generative AI"""
        try:
            # Build messages for the API
            messages = []
            
            # Build the prompt with system context and conversation history
            # Google Gemini doesn't have a dedicated system parameter, so we prepend it to the first user message
            if system_prompt:
                # Combine system prompt with conversation history
                full_context = f"{system_prompt}\n\n--- CONVERSATION ---\n"
                
                # Add conversation history
                for turn in conversation_history:
                    role = "User" if turn["role"] == "user" else "Assistant"
                    full_context += f"{role}: {turn['content']}\n"
                
                # Now the AI should respond as the Assistant
                full_context += "Assistant:"
                
                messages.append({
                    "role": "user",
                    "parts": [{"text": full_context}]
                })
            else:
                # No system prompt, just use conversation history
                for i, turn in enumerate(conversation_history):
                    if i < len(conversation_history) - 1:
                        # Past messages
                        role = "user" if turn["role"] == "user" else "model"
                        messages.append({
                            "role": role,
                            "parts": [{"text": turn["content"]}]
                        })
                    else:
                        # Last message
                        if turn["role"] == "user":
                            messages.append({
                                "role": "user",
                                "parts": [{"text": turn["content"]}]
                            })
            
            # Call Google Generative AI API
            response = self.client.models.generate_content(
                model=self.model,
                contents=messages,
                config={
                    "max_output_tokens": max_tokens,
                    "temperature": temperature,
                }
            )
            
            if response and response.text:
                # Clean up response - remove "Assistant:" prefix if present
                response_text = response.text.strip()
                if response_text.startswith("Assistant:"):
                    response_text = response_text[10:].strip()
                
                logger.debug(f"Generated response: {response_text[:100]}...")
                return response_text
            else:
                logger.warning("Empty response from Google Generative AI")
                return None
                
        except Exception as e:
            logger.error(f"Google Generative AI generation failed: {e}")
            return None
    
    async def generate_evaluation(
        self,
        evaluation_prompt: str,
        transcript: str
    ) -> Optional[str]:
        """Generate evaluation using Google Generative AI"""
        try:
            # Build evaluation message
            full_prompt = f"{evaluation_prompt}\n\nTRANSCRIPT:\n{transcript}"
            
            response = self.client.models.generate_content(
                model=self.model,
                contents=full_prompt,
                config={
                    "max_output_tokens": 1000,
                    "temperature": 0.3,  # Lower temperature for structured output
                }
            )
            
            if response and response.text:
                logger.info(f"Generated evaluation (length: {len(response.text)})")
                return response.text
            else:
                logger.warning("Empty response from evaluation")
                return None
                
        except Exception as e:
            logger.error(f"Google evaluation failed: {e}")
            return None
    
    async def close(self):
        """Close client (no async cleanup needed for google.genai)"""
        pass


# Factory function to create LLM provider
def create_llm_provider(provider_type: str = "google", **kwargs) -> LLMProvider:
    """
    Factory function to create appropriate LLM provider with fallback support
    
    Args:
        provider_type: "google" (primary), "ollama" (fallback), "openai", or "azure"
        **kwargs: Provider-specific configuration
        
    Returns:
        Initialized LLM provider instance
        
    Note:
        If provider_type is "google" but API key is missing or fails,
        automatically falls back to Ollama
    """
    # If Google is requested, try it first
    if provider_type == "google":
        if GOOGLE_API_KEY:
            try:
                return GoogleGenerativeAIProvider(**kwargs)
            except Exception as e:
                logger.warning(f"Google Generative AI initialization failed: {e}. Falling back to Ollama.")
                return OllamaProvider(**kwargs)
        else:
            logger.warning("GOOGLE_API_KEY not set. Falling back to Ollama.")
            return OllamaProvider(**kwargs)
    
    # Default fallback logic for other providers
    if provider_type == "ollama":
        return OllamaProvider(**kwargs)
    elif provider_type == "openai":
        return OpenAIProvider(**kwargs)
    elif provider_type == "azure":
        return AzureOpenAIProvider(**kwargs)
    else:
        # Default to Google with fallback
        if GOOGLE_API_KEY:
            try:
                return GoogleGenerativeAIProvider(**kwargs)
            except Exception as e:
                logger.warning(f"Google Generative AI initialization failed: {e}. Falling back to Ollama.")
                return OllamaProvider(**kwargs)
        else:
            logger.warning("Unknown provider type and GOOGLE_API_KEY not set. Using Ollama.")
            return OllamaProvider(**kwargs)