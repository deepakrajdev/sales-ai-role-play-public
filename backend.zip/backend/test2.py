"""
Comprehensive System Test for Voice-First AI Policy Training System
Tests EVERY component thoroughly
"""
import asyncio
import httpx
import json
import time
import sys
from pathlib import Path
from datetime import datetime

# Color codes for terminal output
class Colors:
    GREEN = '\033[92m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    BOLD = '\033[1m'
    END = '\033[0m'

def print_header(text):
    print(f"\n{Colors.BOLD}{Colors.BLUE}{'='*70}{Colors.END}")
    print(f"{Colors.BOLD}{Colors.BLUE}{text.center(70)}{Colors.END}")
    print(f"{Colors.BOLD}{Colors.BLUE}{'='*70}{Colors.END}\n")

def print_success(text):
    print(f"{Colors.GREEN}✅ {text}{Colors.END}")

def print_error(text):
    print(f"{Colors.RED}❌ {text}{Colors.END}")

def print_warning(text):
    print(f"{Colors.YELLOW}⚠️  {text}{Colors.END}")

def print_info(text):
    print(f"{Colors.BLUE}ℹ️  {text}{Colors.END}")

class SystemTester:
    def __init__(self, base_url="http://localhost:8000"):
        self.base_url = base_url
        self.client = None
        self.test_results = {
            "passed": 0,
            "failed": 0,
            "warnings": 0
        }
        self.session_ids = []
        
    async def run_all_tests(self):
        """Run comprehensive system tests"""
        print_header("🚀 VOICE-FIRST AI TRAINING SYSTEM - COMPREHENSIVE TEST")
        
        start_time = time.time()
        
        # Test categories
        await self.test_prerequisites()
        await self.test_server_connection()
        await self.test_api_endpoints()
        await self.test_session_lifecycle()
        await self.test_database_persistence()
        await self.test_policy_loading()
        await self.test_evaluation_quality()
        await self.test_persona_variations()
        await self.test_error_handling()
        await self.test_edge_cases()
        
        # Summary
        elapsed_time = time.time() - start_time
        self.print_summary(elapsed_time)
        
        return self.test_results["failed"] == 0
    
    async def test_prerequisites(self):
        """Test if all prerequisites are met"""
        print_header("1️⃣ TESTING PREREQUISITES")
        
        # Check Python version
        print_info("Checking Python version...")
        if sys.version_info >= (3, 10):
            print_success(f"Python {sys.version.split()[0]} ✓")
            self.test_results["passed"] += 1
        else:
            print_error(f"Python {sys.version.split()[0]} - Need 3.10+")
            self.test_results["failed"] += 1
        
        # Check required files exist
        print_info("Checking backend files...")
        required_files = [
            'main.py', 'config.py', 'models.py', 'database.py',
            'utils.py', 'llm_provider.py', 'prompts.py',
            'voice_bot.py', 'evaluator.py'
        ]
        
        for file in required_files:
            if Path(file).exists():
                print_success(f"{file} exists")
                self.test_results["passed"] += 1
            else:
                print_error(f"{file} missing!")
                self.test_results["failed"] += 1
        
        # Check directories
        print_info("Checking directories...")
        for directory in ['Policies', 'transcripts']:
            if Path(directory).exists():
                print_success(f"{directory}/ exists")
                self.test_results["passed"] += 1
            else:
                print_warning(f"{directory}/ missing (will be auto-created)")
                self.test_results["warnings"] += 1
        
        # Check for policy PDFs
        print_info("Checking policy PDFs...")
        policies = list(Path('Policies').glob('*.pdf'))
        if policies:
            print_success(f"Found {len(policies)} policy PDF(s)")
            for policy in policies:
                print_info(f"  📄 {policy.name}")
            self.test_results["passed"] += 1
        else:
            print_error("No policy PDFs found in Policies/")
            self.test_results["failed"] += 1
        
        # Check .env file
        print_info("Checking configuration...")
        if Path('.env').exists():
            print_success(".env file exists")
            self.test_results["passed"] += 1
        else:
            print_warning(".env file missing (using defaults)")
            self.test_results["warnings"] += 1
    
    async def test_server_connection(self):
        """Test server connectivity"""
        print_header("2️⃣ TESTING SERVER CONNECTION")
        
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                self.client = client
                
                print_info("Testing server health...")
                response = await client.get(f"{self.base_url}/")
                
                if response.status_code == 200:
                    data = response.json()
                    print_success(f"Server online: {data.get('service', 'Unknown')}")
                    print_info(f"  Version: {data.get('version', 'Unknown')}")
                    self.test_results["passed"] += 1
                else:
                    print_error(f"Server returned {response.status_code}")
                    self.test_results["failed"] += 1
                
                # Check OpenAPI docs
                print_info("Checking API documentation...")
                response = await client.get(f"{self.base_url}/openapi.json")
                if response.status_code == 200:
                    print_success("OpenAPI docs available at /docs")
                    self.test_results["passed"] += 1
                else:
                    print_error("OpenAPI docs not accessible")
                    self.test_results["failed"] += 1
                    
        except httpx.ConnectError:
            print_error("Cannot connect to server!")
            print_info("Make sure server is running: python main.py")
            self.test_results["failed"] += 1
            sys.exit(1)
        except Exception as e:
            print_error(f"Connection error: {e}")
            self.test_results["failed"] += 1
            sys.exit(1)
    
    async def test_api_endpoints(self):
        """Test all REST API endpoints"""
        print_header("3️⃣ TESTING API ENDPOINTS")
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            
            # Test GET /api/policies
            print_info("Testing GET /api/policies...")
            try:
                response = await client.get(f"{self.base_url}/api/policies")
                if response.status_code == 200:
                    policies = response.json()
                    print_success(f"Retrieved {len(policies)} policies")
                    self.test_results["passed"] += 1
                else:
                    print_error(f"Failed: {response.status_code}")
                    self.test_results["failed"] += 1
            except Exception as e:
                print_error(f"Error: {e}")
                self.test_results["failed"] += 1
            
            # Test GET /api/personas
            print_info("Testing GET /api/personas...")
            try:
                response = await client.get(f"{self.base_url}/api/personas")
                if response.status_code == 200:
                    personas = response.json()
                    print_success(f"Retrieved {len(personas)} personas")
                    expected_personas = ['doctor', 'hr_head', 'lawyer', 'judge', 'police_officer', 'ias_officer']
                    for persona in expected_personas:
                        if persona in personas:
                            print_success(f"  ✓ {persona}")
                        else:
                            print_error(f"  ✗ {persona} missing!")
                    self.test_results["passed"] += 1
                else:
                    print_error(f"Failed: {response.status_code}")
                    self.test_results["failed"] += 1
            except Exception as e:
                print_error(f"Error: {e}")
                self.test_results["failed"] += 1
    
    async def test_session_lifecycle(self):
        """Test complete session lifecycle"""
        print_header("4️⃣ TESTING SESSION LIFECYCLE")
        
        async with httpx.AsyncClient(timeout=60.0) as client:
            
            # Get available policies
            response = await client.get(f"{self.base_url}/api/policies")
            policies = response.json()
            
            if not policies:
                print_error("No policies available for testing!")
                self.test_results["failed"] += 1
                return
            
            policy = policies[0]['filename']
            
            # Test session creation
            print_info("Testing session creation...")
            session_data = {
                "mode": "practice_pitch",
                "policy": policy,
                "persona": "doctor"
            }
            
            try:
                response = await client.post(
                    f"{self.base_url}/api/sessions/start",
                    json=session_data
                )
                
                if response.status_code == 200:
                    session = response.json()
                    session_id = session['session_id']
                    self.session_ids.append(session_id)
                    
                    print_success(f"Session created: {session_id}")
                    print_info(f"  Mode: {session['mode']}")
                    print_info(f"  Persona: {session['persona']}")
                    print_info(f"  Policy: {session['policy']}")
                    self.test_results["passed"] += 1
                    
                    # Test session status
                    print_info("Testing session status retrieval...")
                    response = await client.get(
                        f"{self.base_url}/api/sessions/{session_id}/status"
                    )
                    
                    if response.status_code == 200:
                        status = response.json()
                        print_success(f"Status retrieved: {status['status']}")
                        print_info(f"  Turn count: {status['turn_count']}")
                        self.test_results["passed"] += 1
                    else:
                        print_error(f"Status retrieval failed: {response.status_code}")
                        self.test_results["failed"] += 1
                    
                    # Test session ending
                    print_info("Testing session ending...")
                    response = await client.post(
                        f"{self.base_url}/api/sessions/{session_id}/end"
                    )
                    
                    if response.status_code == 200:
                        evaluation = response.json()
                        print_success("Session ended successfully")
                        print_info(f"  Overall Score: {evaluation['scores']['overall']}/100")
                        self.test_results["passed"] += 1
                        
                        # Test evaluation retrieval
                        print_info("Testing evaluation retrieval...")
                        await asyncio.sleep(1)  # Give DB time to save
                        response = await client.get(
                            f"{self.base_url}/api/sessions/{session_id}/evaluation"
                        )
                        
                        if response.status_code == 200:
                            saved_eval = response.json()
                            print_success("Evaluation retrieved from database")
                            self.test_results["passed"] += 1
                        else:
                            print_error(f"Evaluation retrieval failed: {response.status_code}")
                            print_warning("This might be the bug we discussed")
                            self.test_results["failed"] += 1
                    else:
                        print_error(f"Session ending failed: {response.status_code}")
                        self.test_results["failed"] += 1
                        
                else:
                    print_error(f"Session creation failed: {response.status_code}")
                    print_error(f"Response: {response.text}")
                    self.test_results["failed"] += 1
                    
            except Exception as e:
                print_error(f"Session lifecycle error: {e}")
                self.test_results["failed"] += 1
    
    async def test_database_persistence(self):
        """Test database operations"""
        print_header("5️⃣ TESTING DATABASE PERSISTENCE")
        
        try:
            from database import db
            from pathlib import Path
            from config import DATABASE_PATH
            
            print_info("Checking database file...")
            if Path(DATABASE_PATH).exists():
                print_success(f"Database exists: {DATABASE_PATH}")
                print_info(f"  Size: {Path(DATABASE_PATH).stat().st_size} bytes")
                self.test_results["passed"] += 1
            else:
                print_error("Database file not found!")
                self.test_results["failed"] += 1
            
            # Test database operations
            print_info("Testing database queries...")
            
            if self.session_ids:
                session_id = self.session_ids[0]
                session = db.get_session(session_id)
                
                if session:
                    print_success("Session retrieved from database")
                    print_info(f"  Session ID: {session.session_id}")
                    print_info(f"  Status: {session.status}")
                    self.test_results["passed"] += 1
                else:
                    print_error("Failed to retrieve session from database")
                    self.test_results["failed"] += 1
            else:
                print_warning("No sessions to test database retrieval")
                self.test_results["warnings"] += 1
                
        except ImportError as e:
            print_error(f"Cannot import database module: {e}")
            self.test_results["failed"] += 1
        except Exception as e:
            print_error(f"Database test error: {e}")
            self.test_results["failed"] += 1
    
    async def test_policy_loading(self):
        """Test policy PDF loading"""
        print_header("6️⃣ TESTING POLICY LOADING")
        
        try:
            from utils import load_policy_content, get_available_policies
            
            print_info("Testing policy listing...")
            policies = get_available_policies()
            print_success(f"Found {len(policies)} policies")
            self.test_results["passed"] += 1
            
            if policies:
                print_info(f"Testing PDF content extraction...")
                policy_name = policies[0]
                content = load_policy_content(policy_name)
                
                if content:
                    print_success(f"Loaded policy: {policy_name}")
                    print_info(f"  Content length: {len(content)} characters")
                    print_info(f"  First 100 chars: {content[:100]}...")
                    self.test_results["passed"] += 1
                else:
                    print_error(f"Failed to load policy content: {policy_name}")
                    self.test_results["failed"] += 1
            else:
                print_error("No policies available for testing")
                self.test_results["failed"] += 1
                
        except Exception as e:
            print_error(f"Policy loading error: {e}")
            self.test_results["failed"] += 1
    
    async def test_evaluation_quality(self):
        """Test evaluation scoring system"""
        print_header("7️⃣ TESTING EVALUATION QUALITY")
        
        async with httpx.AsyncClient(timeout=90.0) as client:
            
            print_info("Creating test session for evaluation...")
            
            response = await client.get(f"{self.base_url}/api/policies")
            policies = response.json()
            
            if not policies:
                print_error("No policies for evaluation test")
                self.test_results["failed"] += 1
                return
            
            session_data = {
                "mode": "practice_pitch",
                "policy": policies[0]['filename'],
                "persona": "lawyer",
                "traits": {
                    "intelligence": 9,
                    "knowledge": 8,
                    "verbosity": 7,
                    "aggressiveness": 7,
                    "patience": 4
                }
            }
            
            try:
                response = await client.post(
                    f"{self.base_url}/api/sessions/start",
                    json=session_data
                )
                
                if response.status_code == 200:
                    session = response.json()
                    session_id = session['session_id']
                    
                    # Immediately end to test evaluation
                    response = await client.post(
                        f"{self.base_url}/api/sessions/{session_id}/end"
                    )
                    
                    if response.status_code == 200:
                        evaluation = response.json()
                        
                        print_success("Evaluation generated")
                        
                        # Validate evaluation structure
                        print_info("Validating evaluation structure...")
                        
                        required_scores = ['overall', 'product_explanation', 
                                         'communication_skills', 'objection_handling', 
                                         'engagement']
                        
                        all_present = True
                        for score_key in required_scores:
                            if score_key in evaluation['scores']:
                                score = evaluation['scores'][score_key]
                                if 1 <= score <= 100:
                                    print_success(f"  {score_key}: {score}/100 ✓")
                                else:
                                    print_error(f"  {score_key}: {score} (out of range!)")
                                    all_present = False
                            else:
                                print_error(f"  {score_key}: missing!")
                                all_present = False
                        
                        if all_present:
                            self.test_results["passed"] += 1
                        else:
                            self.test_results["failed"] += 1
                        
                        # Validate feedback
                        print_info("Validating feedback...")
                        
                        strengths = evaluation['feedback']['key_strengths']
                        improvements = evaluation['feedback']['areas_of_improvement']
                        
                        if 3 <= len(strengths) <= 4:
                            print_success(f"  Key strengths: {len(strengths)} items ✓")
                            self.test_results["passed"] += 1
                        else:
                            print_error(f"  Key strengths: {len(strengths)} items (expected 3-4)")
                            self.test_results["failed"] += 1
                        
                        if 3 <= len(improvements) <= 4:
                            print_success(f"  Areas of improvement: {len(improvements)} items ✓")
                            self.test_results["passed"] += 1
                        else:
                            print_error(f"  Areas of improvement: {len(improvements)} items (expected 3-4)")
                            self.test_results["failed"] += 1
                    else:
                        print_error("Failed to generate evaluation")
                        self.test_results["failed"] += 1
                else:
                    print_error("Failed to create test session")
                    self.test_results["failed"] += 1
                    
            except Exception as e:
                print_error(f"Evaluation test error: {e}")
                self.test_results["failed"] += 1
    
    async def test_persona_variations(self):
        """Test all persona types"""
        print_header("8️⃣ TESTING PERSONA VARIATIONS")
        
        personas = ['doctor', 'hr_head', 'lawyer', 'judge', 'police_officer', 'ias_officer']
        
        async with httpx.AsyncClient(timeout=60.0) as client:
            
            response = await client.get(f"{self.base_url}/api/policies")
            policies = response.json()
            
            if not policies:
                print_error("No policies for persona testing")
                self.test_results["failed"] += 1
                return
            
            for persona in personas:
                print_info(f"Testing {persona} persona...")
                
                session_data = {
                    "mode": "practice_pitch",
                    "policy": policies[0]['filename'],
                    "persona": persona
                }
                
                try:
                    response = await client.post(
                        f"{self.base_url}/api/sessions/start",
                        json=session_data
                    )
                    
                    if response.status_code == 200:
                        session = response.json()
                        print_success(f"  {persona}: Session created ✓")
                        
                        # Verify traits are set
                        traits = session['traits']
                        if all(1 <= traits[k] <= 10 for k in ['intelligence', 'knowledge', 
                                                               'verbosity', 'aggressiveness', 
                                                               'patience']):
                            print_success(f"  {persona}: Traits valid ✓")
                            self.test_results["passed"] += 1
                        else:
                            print_error(f"  {persona}: Invalid traits")
                            self.test_results["failed"] += 1
                    else:
                        print_error(f"  {persona}: Failed to create session")
                        self.test_results["failed"] += 1
                        
                except Exception as e:
                    print_error(f"  {persona}: Error - {e}")
                    self.test_results["failed"] += 1
    
    async def test_error_handling(self):
        """Test error handling"""
        print_header("9️⃣ TESTING ERROR HANDLING")
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            
            # Test invalid session ID
            print_info("Testing invalid session ID...")
            try:
                response = await client.get(
                    f"{self.base_url}/api/sessions/invalid-id/status"
                )
                
                if response.status_code == 404:
                    print_success("Correctly returns 404 for invalid session")
                    self.test_results["passed"] += 1
                else:
                    print_error(f"Unexpected status code: {response.status_code}")
                    self.test_results["failed"] += 1
            except Exception as e:
                print_error(f"Error handling test failed: {e}")
                self.test_results["failed"] += 1
            
            # Test invalid policy
            print_info("Testing invalid policy name...")
            try:
                session_data = {
                    "mode": "practice_pitch",
                    "policy": "nonexistent_policy.pdf",
                    "persona": "doctor"
                }
                
                response = await client.post(
                    f"{self.base_url}/api/sessions/start",
                    json=session_data
                )
                
                if response.status_code == 404:
                    print_success("Correctly returns 404 for invalid policy")
                    self.test_results["passed"] += 1
                else:
                    print_error(f"Unexpected status code: {response.status_code}")
                    self.test_results["failed"] += 1
            except Exception as e:
                print_error(f"Error handling test failed: {e}")
                self.test_results["failed"] += 1
            
            # Test invalid persona
            print_info("Testing invalid persona...")
            try:
                response = await client.get(f"{self.base_url}/api/policies")
                policies = response.json()
                
                if policies:
                    session_data = {
                        "mode": "practice_pitch",
                        "policy": policies[0]['filename'],
                        "persona": "invalid_persona"
                    }
                    
                    response = await client.post(
                        f"{self.base_url}/api/sessions/start",
                        json=session_data
                    )
                    
                    if response.status_code == 422:
                        print_success("Correctly validates persona (422)")
                        self.test_results["passed"] += 1
                    else:
                        print_error(f"Unexpected status code: {response.status_code}")
                        self.test_results["failed"] += 1
            except Exception as e:
                print_error(f"Error handling test failed: {e}")
                self.test_results["failed"] += 1
    
    async def test_edge_cases(self):
        """Test edge cases and boundary conditions"""
        print_header("🔟 TESTING EDGE CASES")
        
        async with httpx.AsyncClient(timeout=60.0) as client:
            
            # Test custom traits at boundaries
            print_info("Testing boundary trait values...")
            
            response = await client.get(f"{self.base_url}/api/policies")
            policies = response.json()
            
            if not policies:
                print_warning("No policies for edge case testing")
                self.test_results["warnings"] += 1
                return
            
            # Test minimum traits
            session_data = {
                "mode": "learn_policy",
                "policy": policies[0]['filename'],
                "persona": "doctor",
                "traits": {
                    "intelligence": 1,
                    "knowledge": 1,
                    "verbosity": 1,
                    "aggressiveness": 1,
                    "patience": 1
                }
            }
            
            try:
                response = await client.post(
                    f"{self.base_url}/api/sessions/start",
                    json=session_data
                )
                
                if response.status_code == 200:
                    print_success("Minimum traits (1) accepted ✓")
                    self.test_results["passed"] += 1
                else:
                    print_error(f"Minimum traits rejected: {response.status_code}")
                    self.test_results["failed"] += 1
            except Exception as e:
                print_error(f"Edge case test error: {e}")
                self.test_results["failed"] += 1
            
            # Test maximum traits
            session_data["traits"] = {
                "intelligence": 10,
                "knowledge": 10,
                "verbosity": 10,
                "aggressiveness": 10,
                "patience": 10
            }
            
            try:
                response = await client.post(
                    f"{self.base_url}/api/sessions/start",
                    json=session_data
                )
                
                if response.status_code == 200:
                    print_success("Maximum traits (10) accepted ✓")
                    self.test_results["passed"] += 1
                else:
                    print_error(f"Maximum traits rejected: {response.status_code}")
                    self.test_results["failed"] += 1
            except Exception as e:
                print_error(f"Edge case test error: {e}")
                self.test_results["failed"] += 1
            
            # Test both training modes
            print_info("Testing both training modes...")
            
            for mode in ["practice_pitch", "learn_policy"]:
                session_data = {
                    "mode": mode,
                    "policy": policies[0]['filename'],
                    "persona": "doctor"
                }
                
                try:
                    response = await client.post(
                        f"{self.base_url}/api/sessions/start",
                        json=session_data
                    )
                    
                    if response.status_code == 200:
                        print_success(f"  {mode} mode works ✓")
                        self.test_results["passed"] += 1
                    else:
                        print_error(f"  {mode} mode failed")
                        self.test_results["failed"] += 1
                except Exception as e:
                    print_error(f"Mode test error: {e}")
                    self.test_results["failed"] += 1
    
    def print_summary(self, elapsed_time):
        """Print test summary"""
        print_header("📊 TEST SUMMARY")
        
        total_tests = (self.test_results["passed"] + 
                      self.test_results["failed"] + 
                      self.test_results["warnings"])
        
        print(f"\n{Colors.BOLD}Total Tests Run:{Colors.END} {total_tests}")
        print(f"{Colors.GREEN}✅ Passed:{Colors.END} {self.test_results['passed']}")
        print(f"{Colors.RED}❌ Failed:{Colors.END} {self.test_results['failed']}")
        print(f"{Colors.YELLOW}⚠️  Warnings:{Colors.END} {self.test_results['warnings']}")
        
        success_rate = (self.test_results["passed"] / total_tests * 100) if total_tests > 0 else 0
        print(f"\n{Colors.BOLD}Success Rate:{Colors.END} {success_rate:.1f}%")
        print(f"{Colors.BOLD}Time Elapsed:{Colors.END} {elapsed_time:.2f}s")
        
        if self.test_results["failed"] == 0:
            print(f"\n{Colors.GREEN}{Colors.BOLD}🎉 ALL TESTS PASSED! SYSTEM IS READY FOR PRODUCTION!{Colors.END}")
        else:
            print(f"\n{Colors.RED}{Colors.BOLD}⚠️  SOME TESTS FAILED - PLEASE FIX ISSUES ABOVE{Colors.END}")
        
        print("\n" + "="*70 + "\n")


async def main():
    """Main test runner"""
    tester = SystemTester()
    
    try:
        success = await tester.run_all_tests()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print(f"\n{Colors.YELLOW}Tests interrupted by user{Colors.END}")
        sys.exit(1)
    except Exception as e:
        print(f"\n{Colors.RED}Fatal error: {e}{Colors.END}")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())