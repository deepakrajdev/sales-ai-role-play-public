"""
Voice bot pipeline: LLM reasoning and TTS (Piper)
Note: STT (Whisper) removed - using browser Web Speech API instead
"""
import asyncio
import subprocess
import tempfile
import logging
from pathlib import Path
from typing import Optional, List, Dict, Any
from datetime import datetime

from models import (
    SessionStatus, ConversationTurn, TrainingMode,
    PersonaType, PersonalityTraits
)
from llm_provider import LLMProvider, create_llm_provider
from prompts import build_practice_mode_prompt, build_learn_mode_prompt
from config import (
    PIPER_MODEL_PATH, PIPER_EXECUTABLE, SAMPLE_RATE
)
from database import db
from utils import load_policy_content

logger = logging.getLogger(__name__)


class VoiceBot:
    """
    Handles the voice interaction pipeline:
    LLM → Piper (TTS) → Audio
    (STT moved to browser Web Speech API)
    """
    
    def __init__(self, session_id: str):
        self.session_id = session_id
        self.session: Optional[SessionStatus] = None
        self.policy_content: Optional[str] = None
        self.conversation_history: List[Dict[str, str]] = []
        
        # Initialize components
        self.llm_provider: Optional[LLMProvider] = None
        
        # State tracking
        self.turn_count = 0
        self.is_active = False
    
    async def initialize(self) -> bool:
        """
        Initialize the voice bot with session details
        
        Returns:
            True if initialization successful, False otherwise
        """
        try:
            # Load session from database
            self.session = db.get_session(self.session_id)
            if not self.session:
                logger.error(f"Session not found: {self.session_id}")
                return False
            
            # Load policy content
            self.policy_content = load_policy_content(self.session.policy)
            if not self.policy_content:
                logger.error(f"Failed to load policy: {self.session.policy}")
                return False
            
            # Initialize LLM provider (Google with fallback to Ollama)
            self.llm_provider = create_llm_provider("google")
            
            self.is_active = True
            logger.info(f"VoiceBot initialized for session: {self.session_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to initialize VoiceBot: {e}")
            return False
    
    async def process_audio_chunk(self, audio_data: bytes) -> Optional[bytes]:
        """
        Process incoming audio chunk through the complete pipeline
        
        Args:
            audio_data: Raw audio bytes (WAV format)
            
        Returns:
            Generated audio response (WAV format) or None if processing fails
        """
        if not self.is_active:
            logger.warning("VoiceBot not active, cannot process audio")
            return None
        
        try:
            # Step 1: Speech-to-Text (Whisper)
            user_text = await self._transcribe_audio(audio_data)
            if not user_text:
                logger.warning("No speech detected in audio")
                return None
            
            logger.info(f"User said: {user_text}")
            
            # Step 2: Add user turn to conversation
            await self._add_conversation_turn("user", user_text)
            
            # Step 3: Generate AI response (LLM)
            ai_text = await self._generate_ai_response(user_text)
            if not ai_text:
                logger.error("Failed to generate AI response")
                return None
            
            logger.info(f"AI responds: {ai_text}")
            
            # Step 4: Add AI turn to conversation
            await self._add_conversation_turn("ai", ai_text)
            
            # Step 5: Text-to-Speech (Piper)
            ai_audio = await self._synthesize_speech(ai_text)
            if not ai_audio:
                logger.error("Failed to synthesize speech")
                return None
            
            return ai_audio
            
        except Exception as e:
            logger.error(f"Error processing audio chunk: {e}")
            return None
    
    async def _transcribe_audio(self, audio_data: bytes) -> Optional[str]:
        """
        Transcribe audio using faster-whisper
        
        Args:
            audio_data: Raw audio bytes
            
        Returns:
            Transcribed text or None
        """
        try:
            # Save audio to temporary file
            with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as temp_audio:
                temp_audio.write(audio_data)
                temp_path = temp_audio.name
            
            # Transcribe using Whisper
            segments, info = self.whisper_model.transcribe(
                temp_path,
                language="en",
                vad_filter=True,  # Voice activity detection
                vad_parameters=dict(min_silence_duration_ms=500)
            )
            
            # Combine segments
            transcription = " ".join([segment.text for segment in segments]).strip()
            
            # Clean up temp file
            Path(temp_path).unlink()
            
            return transcription if transcription else None
            
        except Exception as e:
            logger.error(f"Whisper transcription failed: {e}")
            return None
    
    async def _generate_ai_response(self, user_message: str) -> Optional[str]:
        """
        Generate AI response using LLM
        
        Args:
            user_message: User's transcribed message
            
        Returns:
            AI response text or None
        """
        try:
            # Build system prompt based on mode
            if self.session.mode == TrainingMode.PRACTICE_PITCH:
                system_prompt = build_practice_mode_prompt(
                    persona=self.session.persona,
                    traits=self.session.traits,
                    policy_content=self.policy_content,
                    turn_count=self.turn_count
                )
            else:  # LEARN_POLICY mode
                system_prompt = build_learn_mode_prompt(
                    policy_content=self.policy_content
                )
            
            # Add current user message to history
            self.conversation_history.append({
                "role": "user",
                "content": user_message
            })
            
            # Generate response
            response = await self.llm_provider.generate_response(
                system_prompt=system_prompt,
                conversation_history=self.conversation_history,
                max_tokens=150 if self.session.traits.verbosity <= 5 else 250,
                temperature=0.8
            )
            
            if response:
                # Add AI response to history
                self.conversation_history.append({
                    "role": "assistant",
                    "content": response
                })
            
            return response
            
        except Exception as e:
            logger.error(f"AI response generation failed: {e}")
            return None
    
    async def _synthesize_speech(self, text: str) -> Optional[bytes]:
        """
        Synthesize speech using Piper TTS
        
        Args:
            text: Text to synthesize
            
        Returns:
            Audio bytes (WAV format) or None
        """
        try:
            # Create temporary output file
            with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as temp_output:
                output_path = temp_output.name
            
            # Run Piper TTS as subprocess
            # Command: echo "text" | piper --model model.onnx --output_file output.wav
            process = await asyncio.create_subprocess_exec(
                PIPER_EXECUTABLE,
                '--model', PIPER_MODEL_PATH,
                '--output_file', output_path,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            
            # Send text to Piper
            stdout, stderr = await process.communicate(input=text.encode('utf-8'))
            
            if process.returncode != 0:
                logger.error(f"Piper TTS failed: {stderr.decode()}")
                return None
            
            # Read generated audio
            with open(output_path, 'rb') as f:
                audio_data = f.read()
            
            # Clean up temp file
            Path(output_path).unlink()
            
            return audio_data
            
        except Exception as e:
            logger.error(f"Speech synthesis failed: {e}")
            return None
    
    async def _add_conversation_turn(self, speaker: str, text: str):
        """
        Add a conversation turn to the database
        
        Args:
            speaker: "user" or "ai"
            text: Spoken text
        """
        self.turn_count += 1
        
        turn = ConversationTurn(
            turn_id=self.turn_count,
            timestamp=datetime.now(),
            speaker=speaker,
            text=text
        )
        
        db.add_conversation_turn(self.session_id, turn)
    
    async def get_ai_greeting(self) -> Optional[bytes]:
        """
        Generate initial AI greeting for the session
        
        Returns:
            Audio bytes of greeting or None
        """
        try:
            # Generate greeting based on mode and persona
            if self.session.mode == TrainingMode.PRACTICE_PITCH:
                greeting = self._generate_practice_greeting()
            else:
                greeting = self._generate_learn_greeting()
            
            logger.info(f"AI greeting: {greeting}")
            
            # Add to conversation
            await self._add_conversation_turn("ai", greeting)
            self.conversation_history.append({
                "role": "assistant",
                "content": greeting
            })
            
            # Synthesize greeting
            return await self._synthesize_speech(greeting)
            
        except Exception as e:
            logger.error(f"Failed to generate greeting: {e}")
            return None
    
    def _generate_practice_greeting(self) -> str:
        """Generate greeting for practice mode"""
        persona_greetings = {
            PersonaType.DOCTOR: "Hello, I have a few minutes between patients. What's this about?",
            PersonaType.HR_HEAD: "Hi there! I'm looking into benefits options for our team. How can you help?",
            PersonaType.LAWYER: "Good afternoon. I'm considering my insurance options. Walk me through this.",
            PersonaType.JUDGE: "Hello. I'd like to understand this policy in detail. Please proceed.",
            PersonaType.POLICE_OFFICER: "Yeah, hello. I got your call about insurance. Make it quick.",
            PersonaType.IAS_OFFICER: "Good day. I'm interested in understanding the policy framework. Please explain."
        }
        return persona_greetings.get(
            self.session.persona,
            "Hello, I'm interested in learning about this insurance policy."
        )
    
    def _generate_learn_greeting(self) -> str:
        """Generate greeting for learn mode"""
        return "Hello! I'm here to help you learn about this policy. What would you like to start with?"
    
    async def cleanup(self):
        """Clean up resources"""
        self.is_active = False
        if self.llm_provider:
            if hasattr(self.llm_provider, 'close'):
                await self.llm_provider.close()
        logger.info(f"VoiceBot cleaned up for session: {self.session_id}")