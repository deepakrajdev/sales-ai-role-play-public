#!/usr/bin/env python3
"""
Quick Verification Script - Tests if backend is responding properly
Run this to verify the backend is working before testing frontend
"""

import requests
import json
import sys
from pathlib import Path

def test_backend():
    """Test if backend is running and responding"""
    
    print("""
╔════════════════════════════════════════════════════════════════╗
║          Backend Quick Verification                           ║
╚════════════════════════════════════════════════════════════════╝
    """)
    
    backend_url = "http://localhost:8000"
    
    # Test 1: Health check
    print("Test 1: Health Check")
    print(f"  URL: {backend_url}/")
    try:
        response = requests.get(f"{backend_url}/", timeout=5)
        if response.status_code == 200:
            data = response.json()
            print(f"  ✅ Backend is running!")
            print(f"     Status: {data.get('status')}")
            print(f"     Service: {data.get('service')}")
            print(f"     Version: {data.get('version')}")
        else:
            print(f"  ❌ HTTP {response.status_code}")
            return False
    except requests.exceptions.ConnectionError:
        print(f"  ❌ Cannot connect to {backend_url}")
        print("     Is backend running? Run: python main.py")
        return False
    except Exception as e:
        print(f"  ❌ Error: {e}")
        return False
    
    # Test 2: Get available policies
    print("\nTest 2: Get Available Policies")
    print(f"  URL: {backend_url}/api/policies")
    try:
        response = requests.get(f"{backend_url}/api/policies", timeout=5)
        if response.status_code == 200:
            policies = response.json()
            print(f"  ✅ Found {len(policies)} policies")
            if policies:
                for policy in policies[:3]:
                    print(f"     • {policy.get('display_name')}")
        else:
            print(f"  ❌ HTTP {response.status_code}")
    except Exception as e:
        print(f"  ❌ Error: {e}")
    
    # Test 3: Get available personas
    print("\nTest 3: Get Available Personas")
    print(f"  URL: {backend_url}/api/personas")
    try:
        response = requests.get(f"{backend_url}/api/personas", timeout=5)
        if response.status_code == 200:
            personas = response.json()
            print(f"  ✅ Found {len(personas)} personas")
            for persona_id in list(personas.keys())[:3]:
                print(f"     • {persona_id}")
        else:
            print(f"  ❌ HTTP {response.status_code}")
    except Exception as e:
        print(f"  ❌ Error: {e}")
    
    # Test 4: Create a session
    print("\nTest 4: Create Session")
    print(f"  URL: {backend_url}/api/sessions/start")
    try:
        payload = {
            "mode": "practice_pitch",
            "policy": "iSelect Smart 360 Term Plan.pdf",
            "persona": "doctor",
            "traits": {
                "intelligence": 5,
                "knowledge": 5,
                "verbosity": 5,
                "aggressiveness": 5,
                "patience": 5
            }
        }
        response = requests.post(
            f"{backend_url}/api/sessions/start",
            json=payload,
            timeout=5
        )
        if response.status_code == 200:
            data = response.json()
            session_id = data.get('session_id')
            print(f"  ✅ Session created!")
            print(f"     Session ID: {session_id}")
            return session_id
        else:
            print(f"  ❌ HTTP {response.status_code}")
            error_data = response.json()
            print(f"     Error: {error_data.get('detail', error_data.get('error'))}")
    except Exception as e:
        print(f"  ❌ Error: {e}")
    
    return False

def test_chat_message(session_id):
    """Test if chat endpoint works"""
    
    if not session_id:
        print("\nSkipping chat test (no session)")
        return
    
    print("\nTest 5: Send Chat Message")
    backend_url = "http://localhost:8000"
    
    try:
        payload = {
            "message": "Hello, I need insurance",
            "session_id": session_id
        }
        print(f"  Message: '{payload['message']}'")
        print(f"  Session: {session_id[:8]}...")
        
        response = requests.post(
            f"{backend_url}/api/chat/message",
            json=payload,
            timeout=10
        )
        
        if response.status_code == 200:
            data = response.json()
            ai_message = data.get('message', '')
            print(f"  ✅ AI Response received!")
            print(f"     Response: {ai_message[:100]}...")
            return True
        else:
            print(f"  ❌ HTTP {response.status_code}")
            error_data = response.json()
            print(f"     Error: {error_data.get('detail', error_data.get('error'))}")
            return False
    except Exception as e:
        print(f"  ❌ Error: {e}")
        return False

def main():
    print(f"\nStarting backend verification...")
    print(f"Python: {sys.version.split()[0]}")
    print(f"Working directory: {Path.cwd()}")
    
    # Test backend
    session_id = test_backend()
    
    # Test chat if session created
    if session_id:
        test_chat_message(session_id)
    
    # Summary
    print("\n" + "="*64)
    print("Summary:")
    if session_id:
        print("✅ Backend is running correctly!")
        print("✅ All tests passed!")
        print("\nYou can now:")
        print("  1. Start frontend: cd frontend && python server.py")
        print("  2. Open http://localhost:5000/index.html")
        print("  3. Test voice calling")
    else:
        print("❌ Backend has issues. Check messages above.")
        print("\nTo fix:")
        print("  1. Make sure Python is installed")
        print("  2. Install requirements: pip install -r requirements.txt")
        print("  3. Run backend: python main.py")
    print("="*64 + "\n")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nAborted by user")
        sys.exit(1)
