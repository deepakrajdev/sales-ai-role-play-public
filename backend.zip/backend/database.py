"""
SQLite database layer for session management and persistence
"""
import sqlite3
import json
from datetime import datetime
from typing import Optional, List, Dict
from contextlib import contextmanager
import logging

from config import DATABASE_PATH
from models import (
    SessionStatus, ConversationTurn, SessionEvaluation,
    TrainingMode, PersonaType, PersonalityTraits
)

logger = logging.getLogger(__name__)


class Database:
    """SQLite database manager for sessions and transcripts"""
    
    def __init__(self, db_path: str = str(DATABASE_PATH)):
        self.db_path = db_path
        self.init_database()
    
    @contextmanager
    def get_connection(self):
        """Context manager for database connections"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row  # Access columns by name
        try:
            yield conn
            conn.commit()
        except Exception as e:
            conn.rollback()
            logger.error(f"Database error: {e}")
            raise
        finally:
            conn.close()
    
    def init_database(self):
        """Initialize database schema"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # Sessions table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS sessions (
                    session_id TEXT PRIMARY KEY,
                    mode TEXT NOT NULL,
                    policy TEXT NOT NULL,
                    persona TEXT NOT NULL,
                    traits TEXT NOT NULL,
                    status TEXT NOT NULL,
                    started_at TIMESTAMP NOT NULL,
                    ended_at TIMESTAMP,
                    turn_count INTEGER DEFAULT 0
                )
            """)
            
            # Conversation turns table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS conversation_turns (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT NOT NULL,
                    turn_id INTEGER NOT NULL,
                    timestamp TIMESTAMP NOT NULL,
                    speaker TEXT NOT NULL,
                    text TEXT NOT NULL,
                    audio_duration REAL,
                    FOREIGN KEY (session_id) REFERENCES sessions(session_id)
                )
            """)
            
            # Evaluations table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS evaluations (
                    session_id TEXT PRIMARY KEY,
                    overall_score INTEGER NOT NULL,
                    product_explanation INTEGER NOT NULL,
                    communication_skills INTEGER NOT NULL,
                    objection_handling INTEGER NOT NULL,
                    engagement INTEGER NOT NULL,
                    key_strengths TEXT NOT NULL,
                    areas_of_improvement TEXT NOT NULL,
                    total_duration REAL NOT NULL,
                    total_turns INTEGER NOT NULL,
                    evaluated_at TIMESTAMP NOT NULL,
                    FOREIGN KEY (session_id) REFERENCES sessions(session_id)
                )
            """)
            
            # Create indexes
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_sessions_started_at 
                ON sessions(started_at)
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_turns_session_id 
                ON conversation_turns(session_id)
            """)
            
            logger.info("Database initialized successfully")
    
    def create_session(
        self,
        session_id: str,
        mode: TrainingMode,
        policy: str,
        persona: PersonaType,
        traits: PersonalityTraits
    ) -> bool:
        """Create a new session record"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO sessions 
                    (session_id, mode, policy, persona, traits, status, started_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (
                    session_id,
                    mode.value,
                    policy,
                    persona.value,
                    traits.model_dump_json(),
                    "active",
                    datetime.now()
                ))
                logger.info(f"Created session: {session_id}")
                return True
        except Exception as e:
            logger.error(f"Failed to create session {session_id}: {e}")
            return False
    
    def add_conversation_turn(
        self,
        session_id: str,
        turn: ConversationTurn
    ) -> bool:
        """Add a conversation turn to the session"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO conversation_turns 
                    (session_id, turn_id, timestamp, speaker, text, audio_duration)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (
                    session_id,
                    turn.turn_id,
                    turn.timestamp,
                    turn.speaker,
                    turn.text,
                    turn.audio_duration
                ))
                
                # Update turn count
                cursor.execute("""
                    UPDATE sessions 
                    SET turn_count = turn_count + 1
                    WHERE session_id = ?
                """, (session_id,))
                
                return True
        except Exception as e:
            logger.error(f"Failed to add turn to {session_id}: {e}")
            return False
    
    def get_session(self, session_id: str) -> Optional[SessionStatus]:
        """Retrieve session details"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                # Get session info
                cursor.execute("""
                    SELECT * FROM sessions WHERE session_id = ?
                """, (session_id,))
                row = cursor.fetchone()
                
                if not row:
                    return None
                
                # Get conversation turns
                cursor.execute("""
                    SELECT * FROM conversation_turns 
                    WHERE session_id = ?
                    ORDER BY turn_id
                """, (session_id,))
                turns_rows = cursor.fetchall()
                
                turns = [
                    ConversationTurn(
                        turn_id=t['turn_id'],
                        timestamp=datetime.fromisoformat(t['timestamp']),
                        speaker=t['speaker'],
                        text=t['text'],
                        audio_duration=t['audio_duration']
                    )
                    for t in turns_rows
                ]
                
                return SessionStatus(
                    session_id=row['session_id'],
                    mode=TrainingMode(row['mode']),
                    policy=row['policy'],
                    persona=PersonaType(row['persona']),
                    traits=PersonalityTraits.model_validate_json(row['traits']),
                    status=row['status'],
                    started_at=datetime.fromisoformat(row['started_at']),
                    ended_at=datetime.fromisoformat(row['ended_at']) if row['ended_at'] else None,
                    turn_count=row['turn_count'],
                    transcript=turns
                )
        except Exception as e:
            logger.error(f"Failed to get session {session_id}: {e}")
            return None
    
    def end_session(self, session_id: str) -> bool:
        """Mark session as ended"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    UPDATE sessions 
                    SET status = 'ended', ended_at = ?
                    WHERE session_id = ?
                """, (datetime.now(), session_id))
                logger.info(f"Ended session: {session_id}")
                return True
        except Exception as e:
            logger.error(f"Failed to end session {session_id}: {e}")
            return False
    
    def save_evaluation(self, evaluation: SessionEvaluation) -> bool:
        """Save session evaluation"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                # Check if evaluation already exists
                cursor.execute("""
                    SELECT session_id FROM evaluations WHERE session_id = ?
                """, (evaluation.session_id,))
                
                existing = cursor.fetchone()
                
                if existing:
                    logger.warning(f"Evaluation already exists for {evaluation.session_id}, updating...")
                    cursor.execute("""
                        UPDATE evaluations 
                        SET overall_score = ?, product_explanation = ?,
                            communication_skills = ?, objection_handling = ?,
                            engagement = ?, key_strengths = ?,
                            areas_of_improvement = ?, total_duration = ?,
                            total_turns = ?, evaluated_at = ?
                        WHERE session_id = ?
                    """, (
                        evaluation.scores.overall,
                        evaluation.scores.product_explanation,
                        evaluation.scores.communication_skills,
                        evaluation.scores.objection_handling,
                        evaluation.scores.engagement,
                        json.dumps(evaluation.feedback.key_strengths),
                        json.dumps(evaluation.feedback.areas_of_improvement),
                        evaluation.total_duration,
                        evaluation.total_turns,
                        evaluation.evaluated_at,
                        evaluation.session_id
                    ))
                else:
                    cursor.execute("""
                        INSERT INTO evaluations 
                        (session_id, overall_score, product_explanation, 
                         communication_skills, objection_handling, engagement,
                         key_strengths, areas_of_improvement, 
                         total_duration, total_turns, evaluated_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        evaluation.session_id,
                        evaluation.scores.overall,
                        evaluation.scores.product_explanation,
                        evaluation.scores.communication_skills,
                        evaluation.scores.objection_handling,
                        evaluation.scores.engagement,
                        json.dumps(evaluation.feedback.key_strengths),
                        json.dumps(evaluation.feedback.areas_of_improvement),
                        evaluation.total_duration,
                        evaluation.total_turns,
                        evaluation.evaluated_at
                    ))
                
                # Explicit commit
                conn.commit()
                logger.info(f"Saved evaluation for session: {evaluation.session_id}")
                return True
        except Exception as e:
            logger.error(f"Failed to save evaluation: {e}")
            return False
    
    def get_evaluation(self, session_id: str) -> Optional[SessionEvaluation]:
        """Retrieve evaluation for a session"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT * FROM evaluations WHERE session_id = ?
                """, (session_id,))
                row = cursor.fetchone()
                
                if not row:
                    return None
                
                from models import EvaluationScores, EvaluationFeedback
                
                return SessionEvaluation(
                    session_id=row['session_id'],
                    scores=EvaluationScores(
                        overall=row['overall_score'],
                        product_explanation=row['product_explanation'],
                        communication_skills=row['communication_skills'],
                        objection_handling=row['objection_handling'],
                        engagement=row['engagement']
                    ),
                    feedback=EvaluationFeedback(
                        key_strengths=json.loads(row['key_strengths']),
                        areas_of_improvement=json.loads(row['areas_of_improvement'])
                    ),
                    total_duration=row['total_duration'],
                    total_turns=row['total_turns'],
                    evaluated_at=datetime.fromisoformat(row['evaluated_at'])
                )
        except Exception as e:
            logger.error(f"Failed to get evaluation for {session_id}: {e}")
            return None


# Global database instance
db = Database()