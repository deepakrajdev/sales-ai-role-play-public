"""
Pydantic models for request/response validation and data structures
"""
from pydantic import BaseModel, Field, field_validator
from typing import Optional, List, Dict
from enum import Enum
from datetime import datetime


class TrainingMode(str, Enum):
    """Training mode options"""
    PRACTICE_PITCH = "practice_pitch"
    LEARN_POLICY = "learn_policy"


class PersonaType(str, Enum):
    """Available AI personas"""
    DOCTOR = "doctor"
    HR_HEAD = "hr_head"
    LAWYER = "lawyer"
    JUDGE = "judge"
    POLICE_OFFICER = "police_officer"
    IAS_OFFICER = "ias_officer"


class PersonalityTraits(BaseModel):
    """Personality trait values (1-10 scale)"""
    intelligence: int = Field(ge=1, le=10, description="Logical reasoning depth")
    knowledge: int = Field(ge=1, le=10, description="Policy knowledge level")
    verbosity: int = Field(ge=1, le=10, description="Response length")
    aggressiveness: int = Field(ge=1, le=10, description="Challenge intensity")
    patience: int = Field(ge=1, le=10, description="Tolerance for vagueness")


# Default persona configurations
DEFAULT_PERSONAS: Dict[PersonaType, PersonalityTraits] = {
    PersonaType.DOCTOR: PersonalityTraits(
        intelligence=8, knowledge=7, verbosity=4, aggressiveness=3, patience=5
    ),
    PersonaType.HR_HEAD: PersonalityTraits(
        intelligence=7, knowledge=6, verbosity=6, aggressiveness=4, patience=7
    ),
    PersonaType.LAWYER: PersonalityTraits(
        intelligence=9, knowledge=8, verbosity=7, aggressiveness=7, patience=4
    ),
    PersonaType.JUDGE: PersonalityTraits(
        intelligence=9, knowledge=7, verbosity=3, aggressiveness=5, patience=8
    ),
    PersonaType.POLICE_OFFICER: PersonalityTraits(
        intelligence=6, knowledge=5, verbosity=5, aggressiveness=6, patience=4
    ),
    PersonaType.IAS_OFFICER: PersonalityTraits(
        intelligence=9, knowledge=8, verbosity=6, aggressiveness=5, patience=9
    ),
}


class SessionStartRequest(BaseModel):
    """Request to start a new training session"""
    mode: TrainingMode
    policy: str = Field(..., description="PDF filename (e.g., 'term_life.pdf')")
    persona: PersonaType
    traits: Optional[PersonalityTraits] = None  # If None, use defaults
    
    @field_validator('policy')
    @classmethod
    def validate_policy_extension(cls, v: str) -> str:
        if not v.endswith('.pdf'):
            return f"{v}.pdf"
        return v


class ConversationTurn(BaseModel):
    """Single turn in the conversation"""
    turn_id: int
    timestamp: datetime
    speaker: str  # "user" or "ai"
    text: str
    audio_duration: Optional[float] = None  # Duration in seconds


class SessionStatus(BaseModel):
    """Current status of a session"""
    session_id: str
    mode: TrainingMode
    policy: str
    persona: PersonaType
    traits: PersonalityTraits
    status: str  # "active", "ended", "error"
    started_at: datetime
    ended_at: Optional[datetime] = None
    turn_count: int
    transcript: List[ConversationTurn] = []


class EvaluationScores(BaseModel):
    """Detailed scoring breakdown"""
    overall: int = Field(ge=1, le=100)
    product_explanation: int = Field(ge=1, le=100)
    communication_skills: int = Field(ge=1, le=100)
    objection_handling: int = Field(ge=1, le=100)
    engagement: int = Field(ge=1, le=100)


class EvaluationFeedback(BaseModel):
    """Qualitative feedback"""
    key_strengths: List[str] = Field(min_items=3, max_items=4)
    areas_of_improvement: List[str] = Field(min_items=3, max_items=4)


class SessionEvaluation(BaseModel):
    """Complete evaluation result"""
    session_id: str
    scores: EvaluationScores
    feedback: EvaluationFeedback
    total_duration: float  # seconds
    total_turns: int
    evaluated_at: datetime


class PolicyInfo(BaseModel):
    """Information about an available policy"""
    filename: str
    display_name: str
    file_size: Optional[int] = None


class ErrorResponse(BaseModel):
    """Standard error response"""
    error: str
    detail: Optional[str] = None
    session_id: Optional[str] = None